-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1771582484,1771582484,0,0,0,0,1,'{\"14f32a04dfb63654a3d61fda72277b6a1cfef679\":{\"identifier\":\"t3information\"},\"b49e071b1b2f90560fd64d245f32134c4f42b980\":{\"identifier\":\"docGettingStarted\"}}','0bc650a5d729e683657fc5f8eaa86e13f29cc566','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('0e1bf7e463d8759ef9637c48f2073ae80f19347fa9c6b95b4594a3974c0d8e7d','[DISABLED]',1,1771591170,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"8cab8cc2da8182381726984e6e0133f6d2a3459ff371278025110923be72cbe2\";}'),
('ab2ed7ce4efc03e4a960f89f185b4b838d773fbbc7c9c96f6dcffa33c0f0cbef','[DISABLED]',3,1771590677,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"84862c1c9923fdfc07faa4f22b8645559126e58d36abaf42d2a7b33b233b480f\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1771582451,1771582451,0,0,0,0,NULL,'a:22:{s:10:\"moduleData\";a:12:{s:28:\"dashboard/current_dashboard/\";s:40:\"0bc650a5d729e683657fc5f8eaa86e13f29cc566\";s:23:\"backend_user_management\";a:0:{}s:14:\"opendocs::open\";a:10:{s:10:\"be_users:1\";a:6:{s:5:\"table\";s:8:\"be_users\";s:3:\"uid\";s:1:\"1\";s:5:\"title\";s:5:\"admin\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:8:\"be_users\";a:1:{i:1;s:4:\"edit\";}}}s:3:\"pid\";i:0;s:9:\"returnUrl\";s:101:\"/typo3/module/users/management?token=2b855111e54c41725ff2d048a688c0316c146281b11a2545b477e03acfa545ba\";}s:14:\"tt_content:NEW\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:3:\"NEW\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:2:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:3:\"new\";}}s:7:\"defVals\";a:1:{s:10:\"tt_content\";a:3:{s:5:\"CType\";s:4:\"text\";s:6:\"colPos\";s:1:\"0\";s:16:\"sys_language_uid\";s:1:\"0\";}}}s:3:\"pid\";i:3;s:9:\"returnUrl\";s:107:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=3#ve-close\";}s:12:\"tt_content:3\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"3\";s:5:\"title\";s:25:\"Visual Editing für TYPO3\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:107:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1#ve-close\";}s:12:\"tt_content:4\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"4\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:4;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:107:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1#ve-close\";}s:12:\"tt_content:8\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"8\";s:5:\"title\";s:6:\"Footer\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:8;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:107:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1#ve-close\";}s:12:\"tt_content:5\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"5\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:5;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:98:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1\";}s:12:\"tt_content:7\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"7\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:7;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:98:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1\";}s:12:\"tt_content:6\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"6\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:6;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:98:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1\";}s:7:\"pages:2\";a:6:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";s:1:\"2\";s:5:\"title\";s:4:\"Home\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:2;s:4:\"edit\";}}}s:3:\"pid\";i:0;s:9:\"returnUrl\";s:98:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1\";}s:7:\"pages:4\";a:6:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";s:1:\"4\";s:5:\"title\";s:8:\"About us\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:4;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:119:\"/typo3/module/web/layout?token=b3c4e64263027241768f57b266583c44a9e69bb4c068d70fc12d72d6e3a832d6&id=3&languages%5B0%5D=1\";}}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:6:\"web_ts\";a:1:{s:6:\"action\";s:17:\"typoscript_active\";}s:23:\"web_typoscript_analyzer\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:9:\"languages\";a:1:{i:0;i:0;}}s:17:\"typoscript_active\";a:7:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}s:9:\"languages\";a:1:{i:0;i:0;}}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:18:\"pagetsconfig_pages\";}s:16:\"opendocs::recent\";a:7:{s:12:\"tt_content:2\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"2\";s:5:\"title\";s:18:\"New Look, New Feel\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:98:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1\";}s:13:\"tt_content:18\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:2:\"18\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:18;s:4:\"edit\";}}}s:3:\"pid\";i:3;s:9:\"returnUrl\";s:107:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=3#ve-close\";}s:7:\"pages:1\";a:6:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";s:1:\"1\";s:5:\"title\";s:4:\"Home\";s:10:\"parameters\";a:2:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}}s:3:\"pid\";i:0;s:9:\"returnUrl\";s:98:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1\";}s:12:\"tt_content:6\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"6\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:6;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:98:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1\";}s:12:\"tt_content:7\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"7\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:7;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:98:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1\";}s:12:\"tt_content:5\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:1:\"5\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:1:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:5;s:4:\"edit\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:98:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1\";}s:14:\"tt_content:NEW\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";s:3:\"NEW\";s:5:\"title\";s:0:\"\";s:10:\"parameters\";a:2:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:3:\"new\";}}s:7:\"defVals\";a:1:{s:10:\"tt_content\";a:3:{s:5:\"CType\";s:18:\"camino_sociallinks\";s:6:\"colPos\";s:2:\"11\";s:16:\"sys_language_uid\";s:1:\"0\";}}}s:3:\"pid\";i:1;s:9:\"returnUrl\";s:107:\"/typo3/module/web/edit?token=5336ee3396ea5c50831e32af22895b6122ab5ba37579532b2ec79cfe3ad1a1e0&id=1#ve-close\";}}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:15:\"1:/user_upload/\";}s:8:\"web_edit\";a:3:{s:8:\"function\";i:1;s:8:\"language\";s:1:\"1\";s:10:\"showHidden\";b:1;}s:10:\"web_layout\";a:3:{s:8:\"viewMode\";s:1:\"2\";s:10:\"showHidden\";b:1;s:9:\"languages\";a:1:{i:0;i:1;}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";s:2:\"50\";s:20:\"edit_docModuleUpload\";i:1;s:15:\"moduleSessionID\";a:12:{s:28:\"dashboard/current_dashboard/\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:23:\"backend_user_management\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:14:\"opendocs::open\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:6:\"web_ts\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:23:\"web_typoscript_analyzer\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:17:\"typoscript_active\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:12:\"pagetsconfig\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:16:\"opendocs::recent\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:16:\"browse_links.php\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:8:\"web_edit\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";s:10:\"web_layout\";s:40:\"fef886c817f5a43cb5591f6c29594f9bbd42dea9\";}s:8:\"realName\";s:0:\"\";s:5:\"email\";s:0:\"\";s:6:\"avatar\";s:0:\"\";s:4:\"lang\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"password2\";s:10:\"!Admin1234\";s:12:\"mfaProviders\";s:0:\"\";s:11:\"colorScheme\";s:4:\"auto\";s:5:\"theme\";s:5:\"fresh\";s:11:\"startModule\";s:0:\"\";s:18:\"backendTitleFormat\";s:10:\"titleFirst\";s:22:\"dateTimeFirstDayOfWeek\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:19:\"displayRecentlyUsed\";s:1:\"1\";s:10:\"copyLevels\";s:1:\"0\";s:10:\"inlineView\";s:699:\"{\"tt_content\":{\"2\":{\"sys_file_reference\":[1]},\"NEW69984c1898470112251398\":{\"tx_themecamino_list_item\":[1,2,3]},\"NEW69984c3d94461179415708\":{\"tx_themecamino_list_item\":[5,6,7]},\"NEW69984c57df97f474719726\":{\"tx_themecamino_list_item\":[8]},\"6\":{\"tx_themecamino_list_item\":{\"0\":\"9\",\"2\":\"8\"}},\"NEW69984c7946cbf324543374\":{\"tx_themecamino_list_item\":[11,12,13,14]},\"NEW69984c96537d4191052013\":{\"tx_themecamino_list_item\":[15]},\"8\":{\"tx_themecamino_list_item\":[\"15\",16,17]},\"7\":{\"tx_themecamino_list_item\":{\"3\":\"11\"}},\"5\":{\"tx_themecamino_list_item\":[\"6\",19]},\"NEW69984f0eb5cd2825992857\":{\"sys_file_reference\":[3],\"tx_themecamino_list_item\":[33,34]},\"NEW69984f5869779723339430\":{\"sys_file_reference\":[4]}}}\";s:13:\"pageLanguages\";a:2:{i:1;a:1:{i:0;i:1;}i:3;a:1:{i:0;i:1;}}}','\"{\\\"emailMeAtLogin\\\":0,\\\"password2\\\":\\\"!Admin1234\\\",\\\"colorScheme\\\":\\\"auto\\\",\\\"theme\\\":\\\"fresh\\\",\\\"startModule\\\":\\\"\\\",\\\"backendTitleFormat\\\":\\\"titleFirst\\\",\\\"dateTimeFirstDayOfWeek\\\":\\\"\\\",\\\"titleLen\\\":\\\"50\\\",\\\"edit_docModuleUpload\\\":1,\\\"showHiddenFilesAndFolders\\\":0,\\\"displayRecentlyUsed\\\":\\\"1\\\",\\\"copyLevels\\\":\\\"0\\\"}\"',0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$RnpSbW0wdjZPb0JNWW56Vg$7zbtqQj28X0Ye+pIdsNZYZv+in3YsUAP0IJKBRhyooU','',0,NULL,'','admin@example.com','',1,3,NULL,1,'en',NULL,'',NULL,1771591168,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(178,'3__0_0_1_1',1774182559,'x��VKo�8�+���%ű���t��^��D��X&,�Z��m��>E�.�=`{�|C�=C��xaEzO�ժx�E^$��{V����-�\"u[$J*��X����n��-�Uq�<CΪH*h@����w������]��T�k�c��*F�E�R>���H�d�؋�źZ_̖��wS$�?�,����W+*�\Z^����gI\Z����8�\r�h�EGz*�S��(�~�����A�.V���_G8+��D�&�I�X\'���#<ʩZu?]��ƿz�$�1�2�=n\\:�t|`!u����+g���>oyu����{C�<l�??|���ǐw�,�lH��W*I�;�.\';�[)�^j���XaLu\"����.X�PǗ)hiOz���ΉM����K��Թ�\ZT���������YjK6C���j֟�t7�6����.�����(�1�}��#W�6`�\"���h�O]\'�D��7öǸ���F��N���Xaq��a;�����\ZT��y\r�b��J����\"��;Ś�k��*�@t��F,�ֱ��N$PQ�c)>!H�\'F�|䢒ν��,�N�R	Z*��tP(0�)� ������Ag`��$����B*�p��j�ǤI�)wux�����%>��~��3I�i@\Z,�X[����a]��,�_M��+8���Ɏ7\r?�c�{쏰�O���l�;V҆����k��kqC���q��1ԑ)������w!.~x!4y%�\\扨=�PҖ�K\Z^�p�U;�rP��A����̳��A��,��pP:ۦsri��[����=(CE�%�|9GgW����,.%ÎzSL�&�I�,N:�)b��?K�Yb��\r\ZBf(ws���B4T�,��z��0T�;�E5�I�<�z�!ge�1[^��d��`c7��ew��a`[T^{\nE`H7��y�>)�	raǴWL�X����ַ�_�o���y֏�7��������3o�ѯn��W���ʖ���-�)�AV��G�6�;�n���*�g����x4����R�{��v����\'iy'),
(179,'3__0_0_0_0',1774182560,'x��VKo�8�+���%ű���t��^��D��X&,�Z��m��>E�.�=`{�|C�=C��xaEzO�ժx�E^$��{V����-�\"u[$J*��X����n��-�Uq�<CΪH*h@����w������]��T�k�c��*F�E�R>���H�d�؋�źZ_̖��wS$�?�,����W+*�\Z^����gI\Z����8�\r�h�EGz*�S��(�~�����A�.V���_G8+��D�&�I�X\'���#<ʩZu?]��ƿz�$�1�2�=n\\:�t|`!u����+g���>oyu����{C�<l�??|���ǐw�,�lH��W*I�;�.\';�[)�^j���XaLu\"����.X�PǗ)hiOz���ΉM����K��Թ�\ZT���������YjK6C���j֟�t7�6����.�����(�1�}��#W�6`�\"���h�O]\'�D��7öǸ���F��N���Xaq��a;�����\ZT��y\r�b��J����\"��;Ś�k��*�@t��F,�ֱ��N$PQ�c)>!H�\'F�|䢒ν��,�N�R	Z*��tP(0�)� ������Ag`��$����B*�p��j�ǤI�)wux�����%>��~��3I�i@\Z,�X[����a]��,�_M��+8���Ɏ7\r?�c�{쏰�O���l�;V҆����k��kqC���q��1ԑ)������w!.~x!4y%�\\扨=�PҖ�K\Z^�p�U;�rP��A����̳��A��,��pP:ۦsri��[����=(CE�%�|9GgW����,.%ÎzSL�&�I�,N:�)b��?K�Yb��\r\ZBf(ws���B4T�,��z��0T�;�E5�I�<�z�!ge�1[^��d��`c7��ew��a`[T^{\nE`H7��y�>)�	raǴWL�X����ַ�_�o���y֏�7��������3o�ѯn��W���ʖ���-�)�AV��G�6�;�n���*�g����x4����R�{��v����\'iy'),
(180,'3__0_0_1_0',1774182560,'x��VKo�8�+���%ű���t��^��D��X&,�Z��m��>E�.�=`{�|C�=C��xaEzO�ժx�E^$��{V����-�\"u[$J*��X����n��-�Uq�<CΪH*h@����w������]��T�k�c��*F�E�R>���H�d�؋�źZ_̖��wS$�?�,����W+*�\Z^����gI\Z����8�\r�h�EGz*�S��(�~�����A�.V���_G8+��D�&�I�X\'���#<ʩZu?]��ƿz�$�1�2�=n\\:�t|`!u����+g���>oyu����{C�<l�??|���ǐw�,�lH��W*I�;�.\';�[)�^j���XaLu\"����.X�PǗ)hiOz���ΉM����K��Թ�\ZT���������YjK6C���j֟�t7�6����.�����(�1�}��#W�6`�\"���h�O]\'�D��7öǸ���F��N���Xaq��a;�����\ZT��y\r�b��J����\"��;Ś�k��*�@t��F,�ֱ��N$PQ�c)>!H�\'F�|䢒ν��,�N�R	Z*��tP(0�)� ������Ag`��$����B*�p��j�ǤI�)wux�����%>��~��3I�i@\Z,�X[����a]��,�_M��+8���Ɏ7\r?�c�{쏰�O���l�;V҆����k��kqC���q��1ԑ)������w!.~x!4y%�\\扨=�PҖ�K\Z^�p�U;�rP��A����̳��A��,��pP:ۦsri��[����=(CE�%�|9GgW����,.%ÎzSL�&�I�,N:�)b��?K�Yb��\r\ZBf(ws���B4T�,��z��0T�;�E5�I�<�z�!ge�1[^��d��`c7��ew��a`[T^{\nE`H7��y�>)�	raǴWL�X����ַ�_�o���y֏�7��������3o�ѯn��W���ʖ���-�)�AV��G�6�;�n���*�g����x4����R�{��v����\'iy'),
(181,'3__1_0_1_0',1774182560,'x��Z�n�8��,���m%َ��p�4@jg}Y��\0�\"юIT%����wxI[N�m�MZ�%��E�pfΜ0���w��\r�Cǿ+��ߩ��6��oy+-Z~��4Hsn��ۗ=a�==����D8��U1�:�\"�)������q��p�ȡ�Yb�*H�/}��tĸ�4�Vl��?\0�������qqNc_\Z�pӄ�7jQ6SnJ�٪\nVU����w��P8��$5\\��q\r;\n��`�쮓��w��b�?:I��X������/2���#��A^�`y\r6+ڄ���IF�hY���5���´]�4����)�{�\Z��C\"+�`j��R\\4t�\"z�Si\'OȊ��{fe�/��˥���>��.�Lbg�*i�T��YwO	�U����36��M��-E	���0�1�����p~��ñ�dq$H�\0�(^�\"ƥ\Z�{C���#rC793��l�|[�֦�[X1��Yu���՗�M������VQ����5)\"y<3D�f(\\�T��j�l�)��/1��J��IV��ۈ$2�K5)�A.`�#bgI���u;�\"|��uh9�SwLnx�b|.��-0�@�I�WbbN3��i\\��E�A��kHTxY��r���\"�6�u�u$���7�X�Ϫ܊P�(4WX���ΐ\r������Q�T�׮b5��Fv��֎��orG�7�P��H\\3˵\\��*T��x�a�.�U%.���U8��zO��%��2/	D��\"Ѧ^	�ff�|8���\rǧ\'�mx��j�0�j\'3h\n����7�i�4Ƿ9�XUF\'#�m���H��/�4�mqkb��@�{�؊v:1������H1,l�BM�W�9���d4m\n��\Z�����(��크���18�V\Z�U�����u�Q{��[L`���6;A���U�Ġ�X�ea^׷�B�>5�q\0N)��8���D����E��-`R�WV��U�L�֝Ԕ������W���۝&[c����,�l��bÙj�P[<����������GjҰ�lэ���q���v5���Ƅ\\�����۷r�֚\rI��?:����g�����h=vgphz���d6����\'����}������N��	4�ǳ���l2F��b:�����?\\L������)��1��./8���l��d�~U�8��� �{�f���A�0�#/�.��o7n�{��r���b8�W�f�dzv�E��d�>P����L�Ŝ����������!���N��cqp�t��naD��8$�n\'�^��:��	܉H�٬o����t�S���5�e5�{�3�\0r�pbm{0�/Zt�=ܧE��jQ�U+O\'FU�%F-X�QE-��J�5������}Q5���j�:,ڂ�\\:��j�����|�RK_���Yl&#zA�!I�\nb�d�����s��\0�L�8�����Y��q�`)KQt\0GI�����$��p	KN`.�ȹ$�35L&Y��63�;cvYW,�$Qe�@����\\����C[>��C[>��C[>�������=�����Z����Ʈ��Í��Src�3o��ۧ{�`M�n5�ϼ?���u�;��2r�%B#��;.����k�\Z	�3p>q/�y���a�}~��Ï|~GRܾ��Bq���������\",���ˋ�t[Z�-�|��h_����x��}*a������cG�{O�����=�\"�}>n��_U��m�󱣧?���oԸ^���\Z�I�{0�1�����v�pz@�zȒC�jh���B\rR�>;��)\r\Z�%�&ْ$_V$;��1����Bˊ-Q�GS|�p�\Z��ʆ_P6�/�M3�}�h����	���/ z�~[�p[�p[�p[�p[��0����β'),
(182,'1__0_0_1_1',1774182562,'x�mUMo�0�/>[�4K���n��.�;	��8Bl˓�&A��>������(��#��HI�Y<1�ِwMV�DU<	R>�V�Z_Ia�am?�7�r�}\\-���U�$��am=RTЀ�<�QTtx$FUƈ�נ�rdK��Z��ɂ�;��2����u�D�| ���o������E�J�F�SZb2��iúz`5�!U[��h�EG{��37����1�r`3�`X�=V��!G6��{���(�M��|*�`�R��Z&\Z��?!��U�F;����+��#P�j=�����Nv���6�;9��Xs�<�kΈ�9�w�����\r����--���[h��%���׳T��ؔێ�C�-�͟�X倎�Q��2�Y0%=Ȧ��h���K�40ŏΔ5�)1�b\r��b�k�4���-�e=�G�*8(�7�{%����f�E�%M�j��d��Y��r��)rSGpd�(x��-p�\n$������­�Y��y���\"�g=�����	^���j54��7�*���d�E~���҇��\'|p\\u���\Z#�k�wG=�^_~>����ۍ��Rh�@��+�θ�%[��\"���V�2!�����S�w�K����48�]|^{]���ƴ]����l��8A6*)�.���z��!�걧F`d���c�j�\076�*��&��f�S�iS�-I[�4\\��A���YO�5jRBF��d �����3(�!���ݤ�(�)�� �B%m夈(U�ޒLd3<6Q�G\0��\Z�մ$S�O.lw�j�f�z��������yO���:�����Ҏ6�hJ_Fa�Yu��F�z~)�$/��_��Xp�#�g#�h7��Ҽ*�u&��t���gSu?Զ%��8���_��O��O������nd��ǩ�f�GrW���N�{:6�g`󎠇���)�'),
(183,'1__0_0_0_0',1774182562,'x�mUMo�0�/>[�4K���n��.�;	��8Bl˓�&A��>������(��#��HI�Y<1�ِwMV�DU<	R>�V�Z_Ia�am?�7�r�}\\-���U�$��am=RTЀ�<�QTtx$FUƈ�נ�rdK��Z��ɂ�;��2����u�D�| ���o������E�J�F�SZb2��iúz`5�!U[��h�EG{��37����1�r`3�`X�=V��!G6��{���(�M��|*�`�R��Z&\Z��?!��U�F;����+��#P�j=�����Nv���6�;9��Xs�<�kΈ�9�w�����\r����--���[h��%���׳T��ؔێ�C�-�͟�X倎�Q��2�Y0%=Ȧ��h���K�40ŏΔ5�)1�b\r��b�k�4���-�e=�G�*8(�7�{%����f�E�%M�j��d��Y��r��)rSGpd�(x��-p�\n$������­�Y��y���\"�g=�����	^���j54��7�*���d�E~���҇��\'|p\\u���\Z#�k�wG=�^_~>����ۍ��Rh�@��+�θ�%[��\"���V�2!�����S�w�K����48�]|^{]���ƴ]����l��8A6*)�.���z��!�걧F`d���c�j�\076�*��&��f�S�iS�-I[�4\\��A���YO�5jRBF��d �����3(�!���ݤ�(�)�� �B%m夈(U�ޒLd3<6Q�G\0��\Z�մ$S�O.lw�j�f�z��������yO���:�����Ҏ6�hJ_Fa�Yu��F�z~)�$/��_��Xp�#�g#�h7��Ҽ*�u&��t���gSu?Զ%��8���_��O��O������nd��ǩ�f�GrW���N�{:6�g`󎠇���)�'),
(184,'1__0_0_1_0',1774182562,'x�mUMo�0�/>[�4K���n��.�;	��8Bl˓�&A��>������(��#��HI�Y<1�ِwMV�DU<	R>�V�Z_Ia�am?�7�r�}\\-���U�$��am=RTЀ�<�QTtx$FUƈ�נ�rdK��Z��ɂ�;��2����u�D�| ���o������E�J�F�SZb2��iúz`5�!U[��h�EG{��37����1�r`3�`X�=V��!G6��{���(�M��|*�`�R��Z&\Z��?!��U�F;����+��#P�j=�����Nv���6�;9��Xs�<�kΈ�9�w�����\r����--���[h��%���׳T��ؔێ�C�-�͟�X倎�Q��2�Y0%=Ȧ��h���K�40ŏΔ5�)1�b\r��b�k�4���-�e=�G�*8(�7�{%����f�E�%M�j��d��Y��r��)rSGpd�(x��-p�\n$������­�Y��y���\"�g=�����	^���j54��7�*���d�E~���҇��\'|p\\u���\Z#�k�wG=�^_~>����ۍ��Rh�@��+�θ�%[��\"���V�2!�����S�w�K����48�]|^{]���ƴ]����l��8A6*)�.���z��!�걧F`d���c�j�\076�*��&��f�S�iS�-I[�4\\��A���YO�5jRBF��d �����3(�!���ݤ�(�)�� �B%m夈(U�ޒLd3<6Q�G\0��\Z�մ$S�O.lw�j�f�z��������yO���:�����Ҏ6�hJ_Fa�Yu��F�z~)�$/��_��Xp�#�g#�h7��Ҽ*�u&��t���gSu?Զ%��8���_��O��O������nd��ǩ�f�GrW���N�{:6�g`󎠇���)�'),
(185,'1__1_0_1_0',1774182562,'x��W�n�8���q�h%_�D}2#\r��Y�^��\0#ѶIT%��7ȿ�P$ER����v�~���s;3�����{�_��s��}��#�}�{��\\|��u�;�d8�����^^�{C�f�Xq�z�2�$�S�.�\"�)���ւ�8%J�H��K���-hח��;��W҂�ٖ�z�Jo�;�_�2,��n�\r$�YB�G�ԃǔ�%8�VxK�a���N��qA2���*B҈]%f��w0�����\\)��$q�h}㒭s��gd��X�X2�J��pg\n�� ��1J�}yH3�Ц�)��5�p��XW�H��w��Jl�ׄ��\Z\"�Eq\n�6el3F�#O��HJB��`yB�T/�p/{C��(�lTHx8���*\0s7�NqcJV���/el�L�<����q�ҳ[�J�&�[n.u���<1��/$霚�sa\09��bx[���7�M\\�ֲ�fq�$s��1��ELJ��Y.��B�F��r�h��HՄحCV=��hE��?Z��Tb�O��X�KT�LJ��������uf��w��p�U�V1�A{BۯR�K!ɫ�H9��	����D���T�� u犒��$�{�gyҟME�\"�;7�^n1��w9b!\04�;Z�U�+	5�E���Z�Hq�����<*�yC����v������]���2��T\n�3>Д\0+E��_¤���*��-�8��\0�!3l>����[���nY��p_\ZROI%Zo��$\'EZ��$�� �J^ׂ������:��_ˇJ�Qhth4�R�)@�q��|�o�ם�m�I��u�@w[] j?�Qpm���)G���X�=��0b6�I#{���nx��\Z��4��Z}�#^�`tݥk�Za�Ҁ<=��$B/�\0�6_W��q�kL�GY=�7�H���Y5*iI=$8�U6آ���[�o��t��[�@���\0}c�½�o555�����;\Z6�|�M�%�\0c�f+P	��m<�C��p+&MkPv��[������̗��Cf���{E�Veҁ:+2\Z���R-��¦�(�.�c�m�t��\0뒦��GZ�H�iI�n�\r��ڕ�����N��tAt��h���g�M�����?>�� h9�c=\rV���s���?P�o��i�opZ-��`6^�.�(X��X^�=ȹէ�E�~�1��Ђ�_SH�����ACN�xj���M��0��]A��a�Sx�L�<�mHDs��<�/�~�Cw���#�\r�l���QLeh�$�_�+���j�^ի���t�L�KF_���p��Á+����$�<�hi�ܺl�A�x��ڪ�5�H�Iŕ�G����/`�`kB`�4q<��=\Z�T����,�UO��Zb�qUK29��4��\r8��!��\rf�\n�t�8}��|ȢC���i2��BG�PC|:��&)G8�AJlNҢ$�f$B�\Z��zf�iE�T��?F��7�i���64\0}��Π��L~	 ��g����K�I>��Y2�i^A�����N���p	��1(�g����h��M�=�\0sN⿍�ޕ�Z?W��894��׭�&fk(��L0�M g�97G�ƛ*I��;���[�������y>O��	�<�\'��|����y�OO���V.b');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(237,'3__0_0_1_1','pageId_1'),
(238,'3__0_0_1_1','pageId_3'),
(239,'3__0_0_0_0','pageId_1'),
(240,'3__0_0_0_0','pageId_3'),
(241,'3__0_0_1_0','pageId_1'),
(242,'3__0_0_1_0','pageId_3'),
(243,'3__1_0_1_0','pageId_1'),
(244,'3__1_0_1_0','pageId_3'),
(245,'1__0_0_1_1','pageId_1'),
(246,'1__0_0_0_0','pageId_1'),
(247,'1__0_0_1_0','pageId_1'),
(248,'1__1_0_1_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_logo` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1771589325,1771582455,0,0,0,0,'',512,NULL,0,0,0,0,NULL,'{\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"target\":\"\",\"title\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\",\"tx_themecamino_logo\":\"\"}',0,0,0,0,1,1,31,31,1,1771589325,0,0,0,0,0.5,1,'Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__CaminoStartpage','pagets__CaminoContentpageSidebar','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(2,0,1771589325,1771589092,0,0,0,0,'',512,NULL,0,1,1,1,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"tx_themecamino_logo\":\"parent\"}','{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"pagets__CaminoStartpage\",\"backend_layout_next_level\":\"pagets__CaminoContentpageSidebar\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"canonical_link\":\"\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"description\":\"\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"fe_group\":\"\",\"hidden\":\"0\",\"is_siteroot\":\"1\",\"keywords\":\"\",\"l10n_source\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"nav_title\":\"\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_description\":\"\",\"og_image\":\"0\",\"og_title\":\"\",\"php_tree_stop\":\"0\",\"rowDescription\":\"\",\"seo_title\":\"\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Home\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"0\",\"twitter_title\":\"\",\"tx_themecamino_logo\":\"0\"}',0,0,0,0,1,1,31,31,1,1771589325,0,0,0,0,0.5,1,'Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__CaminoStartpage','pagets__CaminoContentpageSidebar','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(3,1,1771589738,1771589332,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"title\":\"\"}',0,0,0,0,1,0,31,27,0,1771590212,0,0,0,0,0.5,1,'About Us','/about-us',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(4,1,1771589351,1771589343,0,0,0,0,'',256,NULL,0,1,3,3,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"tx_themecamino_logo\":\"parent\"}','{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"canonical_link\":\"\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"description\":\"\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"fe_group\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"keywords\":\"\",\"l10n_source\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"nav_title\":\"\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_description\":\"\",\"og_image\":\"0\",\"og_title\":\"\",\"php_tree_stop\":\"0\",\"rowDescription\":\"\",\"seo_title\":\"\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/about-us\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"About us\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"0\",\"twitter_title\":\"\",\"tx_themecamino_logo\":\"0\"}',0,0,0,0,1,0,31,27,0,1771590311,0,0,0,0,0.5,1,'About us','/about-us',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1771588509,1771588509,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1771581600,1771581600,0,1,5,'application/x-empty',0,0),
(2,0,1771588525,1771588525,'/user_upload/PinkCat.png','7bea7678c46fd479dd7abdef92c34f251a7f4656','19669f1e02c2f16705ec7587044c66443be70725','png','PinkCat.png','6ca75d361cf37c600b02be312c7e4b01e9523140',1771588524,1771588524,8715121,1,2,'image/png',0,0),
(3,0,1771589440,1771589440,'/user_upload/pp.jpeg','b33b858d894370147ed03b4fd96f3369dca6b7ec','19669f1e02c2f16705ec7587044c66443be70725','jpeg','pp.jpeg','34a376c04a1052c8fe616a5d03a3aac8f4b2761e',1771589440,1771589440,5371,1,2,'image/jpeg',0,0),
(4,0,1771589494,1771589494,'/user_upload/Cat.png','9e46d59583e23d001a5a7db48a04bcbc9ea966f6','19669f1e02c2f16705ec7587044c66443be70725','png','Cat.png','7b19e9e01140e64efe769b05ad263b71e368daf6',1771589494,1771589494,14976005,1,2,'image/png',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1771588509,1771588509,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,0,0),
(2,0,1771588524,1771588524,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,3840,2160),
(3,0,1771589440,1771589440,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,202,203),
(4,0,1771589494,1771589494,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,3840,2160);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1771588524,1771588524,1,2,'/_processed_/3/d/preview_PinkCat_350b892a99.png','preview_PinkCat_350b892a99.png','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.Preview','350b892a99',64,36),
(2,1771588525,1771588525,1,2,'/_processed_/3/d/csm_PinkCat_4a2164c066.png','csm_PinkCat_4a2164c066.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:8.400000000000091;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3823.2;s:9:\"\0*\0height\";d:2160;}}','1e55b432e04a23a8a25cf36eb417b7aedb4a9b62','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','4a2164c066',266,150),
(3,1771588525,1771588525,1,2,'/_processed_/3/d/csm_PinkCat_912c12f8f3.png','csm_PinkCat_912c12f8f3.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:768.72;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2302.56;s:9:\"\0*\0height\";d:2160;}}','9f9c9a7ba540f21fdaed6c0093072594106f66b0','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','912c12f8f3',160,150),
(4,1771588525,1771588525,1,2,'/_processed_/3/d/csm_PinkCat_ae388e94cb.png','csm_PinkCat_ae388e94cb.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:480.3600000000001;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2879.2799999999997;s:9:\"\0*\0height\";d:2160;}}','17eaa370a20abb0fa8968d2baddc486ac4a5a1c2','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','ae388e94cb',200,150),
(5,1771588525,1771588525,1,2,'/_processed_/3/d/csm_PinkCat_0e1e1d0c87.png','csm_PinkCat_0e1e1d0c87.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:300;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3240;s:9:\"\0*\0height\";d:2160;}}','8b0458ca81cb098d32d60ca8bf74d90472add355','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','0e1e1d0c87',225,150),
(6,1771588525,1771588525,1,2,'/_processed_/3/d/csm_PinkCat_e7acfe88d9.png','csm_PinkCat_e7acfe88d9.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:120;s:8:\"\0*\0width\";d:3840;s:9:\"\0*\0height\";d:1920;}}','5c9482d1c89bb571003e173e0141c7d03fda80a5','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','e7acfe88d9',300,150),
(7,1771588525,1771588525,1,2,'/_processed_/3/d/csm_PinkCat_0c6f9c9e96.png','csm_PinkCat_0c6f9c9e96.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','0c6f9c9e96',80,45),
(8,1771588527,1771588526,1,2,'/_processed_/3/d/csm_PinkCat_20773a1fa4.png','csm_PinkCat_20773a1fa4.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1000;s:9:\"maxHeight\";i:1000;s:4:\"crop\";N;}','1097b19f7c94bc1bdd2bf43bfc22198c30890d2e','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','20773a1fa4',1000,563),
(9,1771588527,1771588526,1,2,'/_processed_/3/d/csm_PinkCat_3c1be96d63.png','csm_PinkCat_3c1be96d63.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:300;s:9:\"maxHeight\";i:300;s:4:\"crop\";N;}','e239fcbae08ee546b841850592062fe370de3336','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','3c1be96d63',300,169),
(10,1771588537,1771588537,1,2,'/_processed_/3/d/csm_PinkCat_0687417287.png','csm_PinkCat_0687417287.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:12.240000000000027;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3823.2;s:9:\"\0*\0height\";d:2160;}}','8a7ec40216e06f611995135ff75d06ad3e30b12b','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','0687417287',266,150),
(11,1771588537,1771588537,1,2,'/_processed_/3/d/csm_PinkCat_1ceeea9d68.png','csm_PinkCat_1ceeea9d68.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:1532.88;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2302.56;s:9:\"\0*\0height\";d:2160;}}','7f379034b57f60f759567c1aad27c1e0c126fd57','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','1ceeea9d68',160,150),
(12,1771588537,1771588537,1,2,'/_processed_/3/d/csm_PinkCat_80e544748d.png','csm_PinkCat_80e544748d.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:956.5200000000001;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2879.2799999999997;s:9:\"\0*\0height\";d:2160;}}','c30f6cbe1a1233e54de7aa85f84d25b5cc4a0e0d','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','80e544748d',200,150),
(13,1771588537,1771588537,1,2,'/_processed_/3/d/csm_PinkCat_51b4085d9c.png','csm_PinkCat_51b4085d9c.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:595.6800000000001;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3240;s:9:\"\0*\0height\";d:2160;}}','ac2050ef7e38afb15231a0fbe593e8c1253e212e','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','51b4085d9c',225,150),
(14,1771588537,1771588537,1,2,'/_processed_/3/d/csm_PinkCat_5ffaa226b1.png','csm_PinkCat_5ffaa226b1.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:1.7051509769094082;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3836.589698046181;s:9:\"\0*\0height\";d:1918.2948490230906;}}','c58277114285c751033148aa535d0e6e01c32814','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','5ffaa226b1',300,150),
(15,1771588537,1771588537,1,2,'/_processed_/3/d/csm_PinkCat_43d6a080b9.png','csm_PinkCat_43d6a080b9.png','','a:4:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:11.52;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3824.64;s:9:\"\0*\0height\";d:2160;}}','191c68bed2b9bfe8b7afb9778e28801db76bb69a','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','43d6a080b9',80,45),
(16,1771588539,1771588539,1,2,'/_processed_/3/d/csm_PinkCat_66aea5fe42.webp','csm_PinkCat_66aea5fe42.webp',NULL,'a:8:{s:5:\"width\";s:4:\"960c\";s:6:\"height\";s:4:\"480c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3840;s:9:\"\0*\0height\";d:1918.2948490230906;}s:13:\"fileExtension\";s:4:\"webp\";}','c1fa40cf474ca02e685ef6ec335655d36433b1dc','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','66aea5fe42',960,480),
(17,1771588539,1771588539,1,2,'/_processed_/3/d/csm_PinkCat_c422481743.webp','csm_PinkCat_c422481743.webp',NULL,'a:8:{s:5:\"width\";s:4:\"720c\";s:6:\"height\";s:4:\"480c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:595.2;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3240.96;s:9:\"\0*\0height\";d:2160;}s:13:\"fileExtension\";s:4:\"webp\";}','8a8abc2d33214f955b0665c839cf19c7352095c0','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','c422481743',720,480),
(18,1771588539,1771588539,1,2,'/_processed_/3/d/csm_PinkCat_0f7d6addfa.webp','csm_PinkCat_0f7d6addfa.webp',NULL,'a:8:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"480c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:956.16;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2880;s:9:\"\0*\0height\";d:2160;}s:13:\"fileExtension\";s:4:\"webp\";}','4c740f2ce38479d876b661f8ef304b5a0195dfe1','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','0f7d6addfa',640,480),
(19,1771588539,1771588539,1,2,'/_processed_/3/d/csm_PinkCat_2ca740a8e9.webp','csm_PinkCat_2ca740a8e9.webp',NULL,'a:8:{s:5:\"width\";s:4:\"512c\";s:6:\"height\";s:4:\"480c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:1532.16;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2304;s:9:\"\0*\0height\";d:2160;}s:13:\"fileExtension\";s:4:\"webp\";}','0ea5cacc5ff2a589dfcbb58bed90cbe90274a901','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','2ca740a8e9',512,480),
(20,1771588539,1771588539,1,2,'/_processed_/3/d/csm_PinkCat_4bf00d0872.webp','csm_PinkCat_4bf00d0872.webp',NULL,'a:8:{s:5:\"width\";s:4:\"767c\";s:6:\"height\";s:4:\"432c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;s:13:\"fileExtension\";s:4:\"webp\";}','a45d159770c5592bd6f3f7bf876100b26311fa66','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','4bf00d0872',767,432),
(21,1771588539,1771588539,1,2,'/_processed_/3/d/csm_PinkCat_f05dc09b74.webp','csm_PinkCat_f05dc09b74.webp',NULL,'a:8:{s:5:\"width\";s:4:\"479c\";s:6:\"height\";s:4:\"270c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:11.52;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3824.64;s:9:\"\0*\0height\";d:2160;}s:13:\"fileExtension\";s:4:\"webp\";}','8200703ab29f11a6eea46ea1365e0a5b0f5c92d0','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','f05dc09b74',479,270),
(22,1771589086,1771589085,1,2,'/_processed_/3/d/csm_PinkCat_0c4f6b4176.png','csm_PinkCat_0c4f6b4176.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:11.52;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3824.64;s:9:\"\0*\0height\";d:2160;}}','f9ee6df6a4dd6c2a6e03e6cbba8be2a3bf88e2a7','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','0c4f6b4176',113,64),
(23,1771589086,1771589085,1,2,'/_processed_/3/d/csm_PinkCat_5cb0417b02.png','csm_PinkCat_5cb0417b02.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:1532.16;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2304;s:9:\"\0*\0height\";d:2160;}}','4c0b34d8959d467bac2935bdae8a92d423f42369','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','5cb0417b02',68,64),
(24,1771589086,1771589085,1,2,'/_processed_/3/d/csm_PinkCat_16a2bc1066.png','csm_PinkCat_16a2bc1066.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:956.16;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2880;s:9:\"\0*\0height\";d:2160;}}','58482d5197ac7bc98734d49c5d19c0e120a9f879','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','16a2bc1066',85,64),
(25,1771589086,1771589085,1,2,'/_processed_/3/d/csm_PinkCat_d81d77d2e3.png','csm_PinkCat_d81d77d2e3.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:595.2;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3240.96;s:9:\"\0*\0height\";d:2160;}}','bf45c6df4b3de0f98af3a6cb4a4f31e4c06e2a14','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','d81d77d2e3',96,64),
(26,1771589086,1771589085,1,2,'/_processed_/3/d/csm_PinkCat_56f8e0397a.png','csm_PinkCat_56f8e0397a.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3840;s:9:\"\0*\0height\";d:1918.2948490230906;}}','eb94aab24c1a82f87188fc962e3213f1612ef612','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','56f8e0397a',128,64),
(27,1771589427,1771589427,1,2,'/_processed_/3/d/csm_PinkCat_465abc8152.png','csm_PinkCat_465abc8152.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','6ca75d361cf37c600b02be312c7e4b01e9523140','Image.CropScaleMask','465abc8152',166,93),
(28,1771589440,1771589440,1,3,'/_processed_/d/0/csm_pp_b2b79d3717.jpeg','csm_pp_b2b79d3717.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','34a376c04a1052c8fe616a5d03a3aac8f4b2761e','Image.CropScaleMask','b2b79d3717',114,115),
(29,1771589443,1771589441,1,3,'/_processed_/d/0/csm_pp_ec10b46391.jpeg','csm_pp_ec10b46391.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:0.5;s:8:\"\0*\0width\";d:202;s:9:\"\0*\0height\";d:202;}}','11cbaba83a811c80c93df53072c219ac5fdd6cb0','34a376c04a1052c8fe616a5d03a3aac8f4b2761e','Image.CropScaleMask','ec10b46391',150,150),
(30,1771589442,1771589441,1,3,'/_processed_/d/0/csm_pp_9d266b9e88.jpeg','csm_pp_9d266b9e88.jpeg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','34a376c04a1052c8fe616a5d03a3aac8f4b2761e','Image.CropScaleMask','9d266b9e88',45,45),
(31,1771589455,1771589455,1,3,'/_processed_/d/0/csm_pp_a5687c852b.webp','csm_pp_a5687c852b.webp',NULL,'a:8:{s:5:\"width\";s:4:\"128c\";s:6:\"height\";s:4:\"128c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:0.5;s:8:\"\0*\0width\";d:202;s:9:\"\0*\0height\";d:202;}s:13:\"fileExtension\";s:4:\"webp\";}','6af3c388c45693ba6fb2f7940c2ff2f5eac8555e','34a376c04a1052c8fe616a5d03a3aac8f4b2761e','Image.CropScaleMask','a5687c852b',128,128),
(32,1771589494,1771589494,1,4,'/_processed_/1/2/csm_Cat_621bf842d1.png','csm_Cat_621bf842d1.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','621bf842d1',166,93),
(33,1771589495,1771589495,1,4,'/_processed_/1/2/csm_Cat_6bf2cae6d0.png','csm_Cat_6bf2cae6d0.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:8.400000000000091;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3823.2;s:9:\"\0*\0height\";d:2160;}}','1e55b432e04a23a8a25cf36eb417b7aedb4a9b62','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','6bf2cae6d0',266,150),
(34,1771589495,1771589495,1,4,'/_processed_/1/2/csm_Cat_d1e488bb56.png','csm_Cat_d1e488bb56.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:768.72;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2302.56;s:9:\"\0*\0height\";d:2160;}}','9f9c9a7ba540f21fdaed6c0093072594106f66b0','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','d1e488bb56',160,150),
(35,1771589495,1771589495,1,4,'/_processed_/1/2/csm_Cat_09c497ba55.png','csm_Cat_09c497ba55.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:480.3600000000001;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2879.2799999999997;s:9:\"\0*\0height\";d:2160;}}','17eaa370a20abb0fa8968d2baddc486ac4a5a1c2','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','09c497ba55',200,150),
(36,1771589495,1771589495,1,4,'/_processed_/1/2/csm_Cat_4e3d967079.png','csm_Cat_4e3d967079.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:300;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3240;s:9:\"\0*\0height\";d:2160;}}','8b0458ca81cb098d32d60ca8bf74d90472add355','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','4e3d967079',225,150),
(37,1771589495,1771589495,1,4,'/_processed_/1/2/csm_Cat_9bc0f29ea8.png','csm_Cat_9bc0f29ea8.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:120;s:8:\"\0*\0width\";d:3840;s:9:\"\0*\0height\";d:1920;}}','5c9482d1c89bb571003e173e0141c7d03fda80a5','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','9bc0f29ea8',300,150),
(38,1771589495,1771589495,1,4,'/_processed_/1/2/csm_Cat_f22eb0ee0a.png','csm_Cat_f22eb0ee0a.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','f22eb0ee0a',80,45),
(39,1771589498,1771589498,1,4,'/_processed_/1/2/csm_Cat_4ee42b7625.png','csm_Cat_4ee42b7625.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1000;s:9:\"maxHeight\";i:1000;s:4:\"crop\";N;}','1097b19f7c94bc1bdd2bf43bfc22198c30890d2e','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','4ee42b7625',1000,563),
(40,1771589498,1771589498,1,4,'/_processed_/1/2/csm_Cat_ac28139349.png','csm_Cat_ac28139349.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:300;s:9:\"maxHeight\";i:300;s:4:\"crop\";N;}','e239fcbae08ee546b841850592062fe370de3336','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','ac28139349',300,169),
(41,1771589511,1771589511,1,4,'/_processed_/1/2/csm_Cat_416c5906c6.png','csm_Cat_416c5906c6.png','','a:4:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:7.68;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3824.64;s:9:\"\0*\0height\";d:2160;}}','baf4595e0ff93c6d1c8f0d7677de1be16e8e0348','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','416c5906c6',80,45),
(42,1771589512,1771589512,1,4,'/_processed_/1/2/csm_Cat_e22dbe79f5.webp','csm_Cat_e22dbe79f5.webp',NULL,'a:8:{s:5:\"width\";s:4:\"960c\";s:6:\"height\";s:4:\"480c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3840;s:9:\"\0*\0height\";d:1918.2948490230906;}s:13:\"fileExtension\";s:4:\"webp\";}','c1fa40cf474ca02e685ef6ec335655d36433b1dc','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','e22dbe79f5',960,480),
(43,1771589512,1771589512,1,4,'/_processed_/1/2/csm_Cat_ed7c07e854.webp','csm_Cat_ed7c07e854.webp',NULL,'a:8:{s:5:\"width\";s:4:\"720c\";s:6:\"height\";s:4:\"480c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:380.16;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3240.96;s:9:\"\0*\0height\";d:2160;}s:13:\"fileExtension\";s:4:\"webp\";}','4ca215b180362fbb151f99100a836068aa80b5ce','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','ed7c07e854',720,480),
(44,1771589512,1771589512,1,4,'/_processed_/1/2/csm_Cat_a86169a444.webp','csm_Cat_a86169a444.webp',NULL,'a:8:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"480c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:725.76;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2880;s:9:\"\0*\0height\";d:2160;}s:13:\"fileExtension\";s:4:\"webp\";}','af40270c565bd7f2e8a507094f34350f9a518c92','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','a86169a444',640,480),
(45,1771589512,1771589512,1,4,'/_processed_/1/2/csm_Cat_77b4e419d2.webp','csm_Cat_77b4e419d2.webp',NULL,'a:8:{s:5:\"width\";s:4:\"512c\";s:6:\"height\";s:4:\"480c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:1282.5600000000002;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2304;s:9:\"\0*\0height\";d:2160;}s:13:\"fileExtension\";s:4:\"webp\";}','6911466095663aaafdd4c3782d3ae0bc5bbb5dbc','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','77b4e419d2',512,480),
(46,1771589512,1771589512,1,4,'/_processed_/1/2/csm_Cat_36d09ed2d9.webp','csm_Cat_36d09ed2d9.webp',NULL,'a:8:{s:5:\"width\";s:4:\"767c\";s:6:\"height\";s:4:\"432c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;s:13:\"fileExtension\";s:4:\"webp\";}','a45d159770c5592bd6f3f7bf876100b26311fa66','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','36d09ed2d9',767,432),
(47,1771589512,1771589512,1,4,'/_processed_/1/2/csm_Cat_7f9626462c.webp','csm_Cat_7f9626462c.webp',NULL,'a:8:{s:5:\"width\";s:4:\"479c\";s:6:\"height\";s:4:\"270c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:7.68;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3824.64;s:9:\"\0*\0height\";d:2160;}s:13:\"fileExtension\";s:4:\"webp\";}','c62e7e52838eda98c68cf6b4dff38b9aaa5ba3e4','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','7f9626462c',479,270),
(48,1771589804,1771589804,1,4,'/_processed_/1/2/csm_Cat_34456119f0.png','csm_Cat_34456119f0.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:7.68;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3824.64;s:9:\"\0*\0height\";d:2160;}}','a1bf5543358353b739b501d5a85ab137633f606e','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','34456119f0',113,64),
(49,1771589804,1771589804,1,4,'/_processed_/1/2/csm_Cat_bb3493aabe.png','csm_Cat_bb3493aabe.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:1282.5600000000002;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2304;s:9:\"\0*\0height\";d:2160;}}','14852e91bb3f52e04c3339535bd728b9bc81ad33','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','bb3493aabe',68,64),
(50,1771589804,1771589804,1,4,'/_processed_/1/2/csm_Cat_3fb840dcd1.png','csm_Cat_3fb840dcd1.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:725.76;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:2880;s:9:\"\0*\0height\";d:2160;}}','4b3f6334898b672d8b122ecec8652845993e0ec1','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','3fb840dcd1',85,64),
(51,1771589804,1771589804,1,4,'/_processed_/1/2/csm_Cat_b88e4f45c6.png','csm_Cat_b88e4f45c6.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:380.16;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3240.96;s:9:\"\0*\0height\";d:2160;}}','1a26ff32a0a25e3c5be3d22d2da875134ede5c23','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','b88e4f45c6',96,64),
(52,1771589805,1771589804,1,4,'/_processed_/1/2/csm_Cat_293d0279f0.png','csm_Cat_293d0279f0.png','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:3840;s:9:\"\0*\0height\";d:1918.2948490230906;}}','eb94aab24c1a82f87188fc962e3213f1612ef612','7b19e9e01140e64efe769b05ad263b71e368daf6','Image.CropScaleMask','293d0279f0',128,64),
(53,1771589805,1771589804,1,3,'/_processed_/d/0/csm_pp_bfeba11333.jpeg','csm_pp_bfeba11333.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:0.5;s:8:\"\0*\0width\";d:202;s:9:\"\0*\0height\";d:202;}}','afb2f7be2e45f510e70fb274448a2e4b1f443810','34a376c04a1052c8fe616a5d03a3aac8f4b2761e','Image.CropScaleMask','bfeba11333',64,64);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,1,1771588536,1771588536,0,0,0,0,NULL,'',0,0,0,0,2,NULL,NULL,2,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"height\":1,\"width\":0.996,\"x\":0.003,\"y\":0},\"selectedRatio\":\"16:9\",\"focusArea\":null,\"excludeFromSync\":false},\"sm\":{\"cropArea\":{\"height\":1,\"width\":0.6,\"x\":0.399,\"y\":0},\"selectedRatio\":\"16:15\",\"focusArea\":null,\"excludeFromSync\":false},\"md\":{\"cropArea\":{\"height\":1,\"width\":0.75,\"x\":0.249,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null,\"excludeFromSync\":false},\"lg\":{\"cropArea\":{\"height\":1,\"width\":0.844,\"x\":0.155,\"y\":0},\"selectedRatio\":\"3:2\",\"focusArea\":null,\"excludeFromSync\":false},\"xl\":{\"cropArea\":{\"height\":0.8880994671403197,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"2:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(2,1,1771589092,1771589092,0,0,1,1,NULL,'{\"alternative\":\"\",\"autoplay\":\"0\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.996,\\\"x\\\":0.003,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.6,\\\"x\\\":0.399,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:15\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.75,\\\"x\\\":0.249,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"4:3\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.844,\\\"x\\\":0.155,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"height\\\":0.8880994671403197,\\\"width\\\":1,\\\"x\\\":0,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"2:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"description\":\"\",\"fieldname\":\"image\",\"hidden\":\"0\",\"link\":\"\",\"sorting_foreign\":\"1\",\"tablenames\":\"tt_content\",\"title\":\"\",\"uid_foreign\":\"2\",\"uid_local\":\"2\"}',0,0,0,0,2,NULL,NULL,9,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"height\":1,\"width\":0.996,\"x\":0.003,\"y\":0},\"selectedRatio\":\"16:9\",\"focusArea\":null,\"excludeFromSync\":false},\"sm\":{\"cropArea\":{\"height\":1,\"width\":0.6,\"x\":0.399,\"y\":0},\"selectedRatio\":\"16:15\",\"focusArea\":null,\"excludeFromSync\":false},\"md\":{\"cropArea\":{\"height\":1,\"width\":0.75,\"x\":0.249,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null,\"excludeFromSync\":false},\"lg\":{\"cropArea\":{\"height\":1,\"width\":0.844,\"x\":0.155,\"y\":0},\"selectedRatio\":\"3:2\",\"focusArea\":null,\"excludeFromSync\":false},\"xl\":{\"cropArea\":{\"height\":0.8880994671403197,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"2:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(3,3,1771589455,1771589455,0,0,0,0,NULL,'',0,0,0,0,3,NULL,NULL,17,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0.0024630541871921183,\"width\":1,\"height\":0.9950738916256158},\"selectedRatio\":\"1:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(4,3,1771589511,1771589511,0,0,0,0,NULL,'',0,0,0,0,4,NULL,NULL,18,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"height\":1,\"width\":0.996,\"x\":0.002,\"y\":0},\"selectedRatio\":\"16:9\",\"focusArea\":null,\"excludeFromSync\":false},\"sm\":{\"cropArea\":{\"height\":1,\"width\":0.6,\"x\":0.334,\"y\":0},\"selectedRatio\":\"16:15\",\"focusArea\":null,\"excludeFromSync\":false},\"md\":{\"cropArea\":{\"height\":1,\"width\":0.75,\"x\":0.189,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null,\"excludeFromSync\":false},\"lg\":{\"cropArea\":{\"height\":1,\"width\":0.844,\"x\":0.099,\"y\":0},\"selectedRatio\":\"3:2\",\"focusArea\":null,\"excludeFromSync\":false},\"xl\":{\"cropArea\":{\"height\":0.8880994671403197,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"2:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(5,3,1771589810,1771589810,0,0,1,4,NULL,'{\"alternative\":\"\",\"autoplay\":\"0\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.996,\\\"x\\\":0.002,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.6,\\\"x\\\":0.334,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:15\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.75,\\\"x\\\":0.189,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"4:3\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.844,\\\"x\\\":0.099,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"height\\\":0.8880994671403197,\\\"width\\\":1,\\\"x\\\":0,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"2:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"description\":\"\",\"fieldname\":\"image\",\"hidden\":\"0\",\"link\":\"\",\"sorting_foreign\":\"1\",\"tablenames\":\"tt_content\",\"title\":\"\",\"uid_foreign\":\"18\",\"uid_local\":\"4\"}',0,0,0,0,4,NULL,NULL,20,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"height\":1,\"width\":0.996,\"x\":0.002,\"y\":0},\"selectedRatio\":\"16:9\",\"focusArea\":null,\"excludeFromSync\":false},\"sm\":{\"cropArea\":{\"height\":1,\"width\":0.6,\"x\":0.334,\"y\":0},\"selectedRatio\":\"16:15\",\"focusArea\":null,\"excludeFromSync\":false},\"md\":{\"cropArea\":{\"height\":1,\"width\":0.75,\"x\":0.189,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null,\"excludeFromSync\":false},\"lg\":{\"cropArea\":{\"height\":1,\"width\":0.844,\"x\":0.099,\"y\":0},\"selectedRatio\":\"3:2\",\"focusArea\":null,\"excludeFromSync\":false},\"xl\":{\"cropArea\":{\"height\":0.8880994671403197,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"2:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(6,3,1771589810,1771589810,0,0,1,3,NULL,'{\"alternative\":\"\",\"autoplay\":\"0\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.0024630541871921183,\\\"width\\\":1,\\\"height\\\":0.9950738916256158},\\\"selectedRatio\\\":\\\"1:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"description\":\"\",\"fieldname\":\"image\",\"hidden\":\"0\",\"link\":\"\",\"sorting_foreign\":\"1\",\"tablenames\":\"tt_content\",\"title\":\"\",\"uid_foreign\":\"17\",\"uid_local\":\"3\"}',0,0,0,0,3,NULL,NULL,22,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0.0024630541871921183,\"width\":1,\"height\":0.9950738916256158},\"selectedRatio\":\"1:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1771585619,1771585619,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1771585905,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"fe_group\":\"0\",\"l10n_diffsource\":null},\"newRecord\":{\"backend_layout\":\"pagets__CaminoStartpage\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"\\\"}\"}}',0,'0400$63346267e0bca1d44cc49cd8dab2efc4:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1771585966,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"header\":\"Welcome to your default website\",\"l18n_diffsource\":null},\"newRecord\":{\"header\":\"Welcome to your default website A\",\"l18n_diffsource\":\"{\\\"header\\\":\\\"\\\"}\"}}',0,'0400$c8698bb7603c1c03969c6322def64cb3:7fa2c035f26826fe83eeecaaeddc4d40'),
(3,1771588457,1,'BE',1,0,2,'tt_content','{\"CType\":\"camino_hero_small\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"New Look, New Feel\",\"subheader\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_config\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1771588457,\"t3ver_stage\":0,\"tstamp\":1771588457,\"uid\":2}',0,'0400$7cad741de8562f24e4ea528d7b1b0154:01dbc21fdb1263685b9147b3b1596ea8'),
(4,1771588472,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"subheader\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"subheader\":\"A fresh foundation for every project\",\"l18n_diffsource\":\"{\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$2cdbfdcb20621f1fba8bbf43c730ed3c:01dbc21fdb1263685b9147b3b1596ea8'),
(5,1771588480,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"tx_themecamino_link_label\":\"\",\"l18n_diffsource\":\"{\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_themecamino_link_label\":\"Read more\",\"l18n_diffsource\":\"{\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"}}',0,'0400$e55dda3e2a1293f5f0bf0d80c29e5c2f:01dbc21fdb1263685b9147b3b1596ea8'),
(6,1771588501,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"tx_themecamino_link\":\"\",\"l18n_diffsource\":\"{\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_themecamino_link\":\"https:\\/\\/github.com\\/andersundsehr\\/visual_editor\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"}}',0,'0400$5807ac74716667edc53da9193ad35ffb:01dbc21fdb1263685b9147b3b1596ea8'),
(7,1771588536,1,'BE',1,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.996,\\\"x\\\":0.003,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.6,\\\"x\\\":0.399,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:15\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.75,\\\"x\\\":0.249,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"4:3\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.844,\\\"x\\\":0.155,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"height\\\":0.8880994671403197,\\\"width\\\":1,\\\"x\\\":0,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"2:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"2\",\"sys_language_uid\":0,\"crdate\":1771588536,\"t3ver_stage\":0,\"tstamp\":1771588536,\"uid\":1}',0,'0400$f09cc5dca409078b95f4ad1535928629:4cf496f597e7b095ce8b755e6cec3c0c'),
(8,1771588552,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"header\":\"Welcome to your default website A\",\"bodytext\":\"<p>This website is made with <a href=\\\"https:\\/\\/typo3.org\\\" target=\\\"_blank\\\" rel=\\\"noreferrer\\\">TYPO3<\\/a>.<\\/p>\",\"l18n_diffsource\":\"{\\\"header\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Benefits\",\"bodytext\":\"<h2>\\ud83d\\ude80 Publish faster<\\/h2>\\r\\n<p>Small changes (headlines, teasers, CTA copy) take seconds instead of minutes.<\\/p>\\r\\n<h2>\\ud83c\\udfaf Fewer errors, less back-and-forth<\\/h2>\\r\\n<p>Edits happen in layout context \\u2014 fewer \\u201cOops, wrong content block\\u201d moments.<\\/p>\\r\\n<h2>\\ud83e\\udde0 Less training required<\\/h2>\\r\\n<p>Editors get it instantly: click = edit.<\\/p>\\r\\n<h2>\\ud83e\\udde9 Built for TYPO3<\\/h2>\\r\\n<p>No foreign layer, no \\u201csecond CMS\\u201d. Cleanly integrated into the TYPO3 ecosystem.<\\/p>\",\"l18n_diffsource\":\"{\\\"bodytext\\\":\\\"\\\",\\\"header\\\":\\\"\\\"}\"}}',0,'0400$c71a0d59375534aaa9f6ab71602a40f6:7fa2c035f26826fe83eeecaaeddc4d40'),
(9,1771588619,1,'BE',1,0,3,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":768,\"sys_language_uid\":0,\"header\":\"Visual Editing f\\u00fcr TYPO3\",\"subheader\":\"Because it is just natural that way.\",\"bodytext\":\"<p>Edit content directly where it\'s created: on the page. No more form streaks or tab hopping \\u2014 just click, tap, and you\'re done. <strong>What you see is what you ship:<\\/strong> <a href=\\\"t3:\\/\\/page?uid=15\\\">headlines<\\/a>, teasers, and CTAs update in context, so teams move faster, make fewer mistakes, and need less back-and-forth.<\\/p>\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_config\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1771588619,\"t3ver_stage\":0,\"tstamp\":1771588619,\"uid\":3}',0,'0400$a5fae287d0eea108f0b62b9fbb733119:b92300cfb5d1d3645c9cb212a7f56c1f'),
(10,1771588620,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"}}',0,'0400$344d679c49a352cd520089ac631b567a:b92300cfb5d1d3645c9cb212a7f56c1f'),
(11,1771588625,3,'BE',1,0,3,'tt_content','{\"oldData\":{\"pid\":1,\"tstamp\":1771588620,\"sorting\":768},\"newData\":{\"tstamp\":1771588625,\"sorting\":128,\"pid\":1}}',0,'0400$50e359085b01f658090c3f985b6d8bbf:b92300cfb5d1d3645c9cb212a7f56c1f'),
(12,1771588625,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$6424183e151f23e3d9e54bd7e13f7f71:b92300cfb5d1d3645c9cb212a7f56c1f'),
(13,1771588651,1,'BE',1,0,4,'tt_content','{\"CType\":\"camino_sociallinks\",\"colPos\":\"11\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":64,\"sys_language_uid\":0,\"header\":\"\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1771588651,\"t3ver_stage\":0,\"tstamp\":1771588651,\"uid\":4}',0,'0400$26d82e3cfe5bde452cc85eb7ae194bd0:4d391f5ef79b8d5d10dffa8a07ca167d'),
(14,1771588651,1,'BE',1,0,1,'tx_themecamino_list_item','{\"sorting_foreign\":256,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/www.instagram.com\\/anders.und.sehr\\/\",\"link_label\":\"\",\"sys_language_uid\":0,\"crdate\":1771588651,\"t3ver_stage\":0,\"tstamp\":1771588651,\"uid\":1}',0,'0400$26d82e3cfe5bde452cc85eb7ae194bd0:dd25f3e4015703e546899e3ebabd22e9'),
(15,1771588651,1,'BE',1,0,2,'tx_themecamino_list_item','{\"sorting_foreign\":128,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/www.facebook.com\\/andersundsehr\",\"link_label\":\"\",\"sys_language_uid\":0,\"crdate\":1771588651,\"t3ver_stage\":0,\"tstamp\":1771588651,\"uid\":2}',0,'0400$26d82e3cfe5bde452cc85eb7ae194bd0:e630006f70f868f0b396aa20096c8b34'),
(16,1771588651,1,'BE',1,0,3,'tx_themecamino_list_item','{\"sorting_foreign\":64,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/de.linkedin.com\\/company\\/anders-und-sehr\",\"link_label\":\"\",\"sys_language_uid\":0,\"crdate\":1771588651,\"t3ver_stage\":0,\"tstamp\":1771588651,\"uid\":3}',0,'0400$26d82e3cfe5bde452cc85eb7ae194bd0:31a5c3914b4b733b3821fb4d1641a707'),
(17,1771588651,1,'BE',1,0,4,'tx_themecamino_list_item','{\"sorting_foreign\":32,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/www.xing.com\\/pages\\/andersundsehrgmbh\",\"link_label\":\"\",\"sys_language_uid\":0,\"crdate\":1771588651,\"t3ver_stage\":0,\"tstamp\":1771588651,\"uid\":4}',0,'0400$26d82e3cfe5bde452cc85eb7ae194bd0:8661ed16d641b0b51234a4acc99c9ffa'),
(18,1771588687,1,'BE',1,0,5,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"12\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":32,\"sys_language_uid\":0,\"header\":\"\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1771588687,\"t3ver_stage\":0,\"tstamp\":1771588687,\"uid\":5}',0,'0400$434ea045899ccc4a7a2178493c7bedc1:c7626fc9bcba6f70beb6ebc085a400db'),
(19,1771588687,1,'BE',1,0,5,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/aus_driver_amazon_s3\",\"link_label\":\"ET:aus_driver_amazon_s3\",\"sys_language_uid\":0,\"crdate\":1771588687,\"t3ver_stage\":0,\"tstamp\":1771588687,\"uid\":5}',0,'0400$434ea045899ccc4a7a2178493c7bedc1:553a0b94d31bc6d75a24b3146e82c7b9'),
(20,1771588687,1,'BE',1,0,6,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/webdevops\\/Dockerfile\",\"link_label\":\"webdevops\\/php\",\"sys_language_uid\":0,\"crdate\":1771588687,\"t3ver_stage\":0,\"tstamp\":1771588687,\"uid\":6}',0,'0400$434ea045899ccc4a7a2178493c7bedc1:a29cdb6aa8f1e8ff8bf21ca01298a2a5'),
(21,1771588687,1,'BE',1,0,7,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/storybook\",\"link_label\":\"EXT:storybook\",\"sys_language_uid\":0,\"crdate\":1771588687,\"t3ver_stage\":0,\"tstamp\":1771588687,\"uid\":7}',0,'0400$434ea045899ccc4a7a2178493c7bedc1:c42cb0131c55877d6432782967a88164'),
(22,1771588702,1,'BE',1,0,6,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"13\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":16,\"sys_language_uid\":0,\"header\":\"\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1771588702,\"t3ver_stage\":0,\"tstamp\":1771588702,\"uid\":6}',0,'0400$a39a1add74dce7a626b5f4500c236920:c0db6803ab1ec5f70c36e2a72187867b'),
(23,1771588702,1,'BE',1,0,8,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\",\"link_label\":\"https:\\/\\/github.com\\/andersundsehr\",\"sys_language_uid\":0,\"crdate\":1771588702,\"t3ver_stage\":0,\"tstamp\":1771588702,\"uid\":8}',0,'0400$a39a1add74dce7a626b5f4500c236920:61d4a0fd373c5c9c133848e4e4d98b45'),
(24,1771588715,2,'BE',1,0,8,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$ac7c28413a6de41597b232b0cdea5908:61d4a0fd373c5c9c133848e4e4d98b45'),
(25,1771588715,1,'BE',1,0,9,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/storybook\",\"link_label\":\"EXT:storybook\",\"sys_language_uid\":0,\"crdate\":1771588715,\"t3ver_stage\":0,\"tstamp\":1771588715,\"uid\":9}',0,'0400$ac7c28413a6de41597b232b0cdea5908:e5291482bfd8fb9250717d6978c85a9d'),
(26,1771588715,1,'BE',1,0,10,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/aus_driver_amazon_s3\",\"link_label\":\"ET:aus_driver_amazon_s3\",\"sys_language_uid\":0,\"crdate\":1771588715,\"t3ver_stage\":0,\"tstamp\":1771588715,\"uid\":10}',0,'0400$ac7c28413a6de41597b232b0cdea5908:e94df647818cf75d345ec41f8addf24c'),
(27,1771588721,2,'BE',1,0,9,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$6d7fffb8bd659dfa8856ddc4f08e4755:e5291482bfd8fb9250717d6978c85a9d'),
(28,1771588721,2,'BE',1,0,10,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$6d7fffb8bd659dfa8856ddc4f08e4755:e94df647818cf75d345ec41f8addf24c'),
(29,1771588749,1,'BE',1,0,7,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"14\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":8,\"sys_language_uid\":0,\"header\":\"\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1771588749,\"t3ver_stage\":0,\"tstamp\":1771588749,\"uid\":7}',0,'0400$412e91175953f95ff7cde8f74be59286:ea41b626baac59a1fe0716bc344af5d9'),
(30,1771588749,1,'BE',1,0,11,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/storybook\",\"link_label\":\"EXT:storybook\",\"sys_language_uid\":0,\"crdate\":1771588749,\"t3ver_stage\":0,\"tstamp\":1771588749,\"uid\":11}',0,'0400$412e91175953f95ff7cde8f74be59286:fac8d56653c7e446ea9b5b9f3a3630fe'),
(31,1771588749,1,'BE',1,0,12,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/aus_driver_amazon_s3\",\"link_label\":\"ET:aus_driver_amazon_s3\",\"sys_language_uid\":0,\"crdate\":1771588749,\"t3ver_stage\":0,\"tstamp\":1771588749,\"uid\":12}',0,'0400$412e91175953f95ff7cde8f74be59286:33a5acd1e8390d67d0bf39f5ec009db0'),
(32,1771588749,1,'BE',1,0,13,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"http:\\/\\/github.com\\/pluswerk\\/php-dev\",\"link_label\":\"php-dev\",\"sys_language_uid\":0,\"crdate\":1771588749,\"t3ver_stage\":0,\"tstamp\":1771588749,\"uid\":13}',0,'0400$412e91175953f95ff7cde8f74be59286:0f1fa0fa151eb565f5e8d354a5f5cea8'),
(33,1771588749,1,'BE',1,0,14,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\",\"link_label\":\"https:\\/\\/github.com\\/andersundsehr\",\"sys_language_uid\":0,\"crdate\":1771588749,\"t3ver_stage\":0,\"tstamp\":1771588749,\"uid\":14}',0,'0400$412e91175953f95ff7cde8f74be59286:d00d327965770bf21b1db955767c244b'),
(34,1771588750,2,'BE',1,0,11,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4a6c023144ea8cd343aa68ee63baf101:fac8d56653c7e446ea9b5b9f3a3630fe'),
(35,1771588750,2,'BE',1,0,12,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4a6c023144ea8cd343aa68ee63baf101:33a5acd1e8390d67d0bf39f5ec009db0'),
(36,1771588750,2,'BE',1,0,13,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4a6c023144ea8cd343aa68ee63baf101:0f1fa0fa151eb565f5e8d354a5f5cea8'),
(37,1771588750,2,'BE',1,0,14,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4a6c023144ea8cd343aa68ee63baf101:d00d327965770bf21b1db955767c244b'),
(38,1771588772,1,'BE',1,0,8,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"10\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":4,\"sys_language_uid\":0,\"header\":\"Footer\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1771588772,\"t3ver_stage\":0,\"tstamp\":1771588772,\"uid\":8}',0,'0400$83b62917940c7247142785ab7f43f2ab:2097d84972a039cb6bfe093b17089287'),
(39,1771588772,1,'BE',1,0,15,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"t3:\\/\\/page?uid=1\",\"link_label\":\"Impressum\",\"sys_language_uid\":0,\"crdate\":1771588772,\"t3ver_stage\":0,\"tstamp\":1771588772,\"uid\":15}',0,'0400$83b62917940c7247142785ab7f43f2ab:0e96270cc28b0e0448e8c8d3bf6087ec'),
(40,1771588790,2,'BE',1,0,15,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$347121fab85bd4a6752ede4c005a6241:0e96270cc28b0e0448e8c8d3bf6087ec'),
(41,1771588790,1,'BE',1,0,16,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"t3:\\/\\/page?uid=1\",\"link_label\":\"Legal\",\"sys_language_uid\":0,\"crdate\":1771588790,\"t3ver_stage\":0,\"tstamp\":1771588790,\"uid\":16}',0,'0400$347121fab85bd4a6752ede4c005a6241:e341eebdf1a80bbe5c2280ad0071cbfd'),
(42,1771588790,1,'BE',1,0,17,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"t3:\\/\\/page?uid=1\",\"link_label\":\"Datenschutzhinwei\\u00df\",\"sys_language_uid\":0,\"crdate\":1771588790,\"t3ver_stage\":0,\"tstamp\":1771588790,\"uid\":17}',0,'0400$347121fab85bd4a6752ede4c005a6241:cdce7c684835f1aff41674d980a594c4'),
(43,1771588821,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":3},\"newRecord\":{\"tx_themecamino_list_elements\":2}}',0,'0400$a54232e2b1367d7a7e907078115a752f:2097d84972a039cb6bfe093b17089287'),
(44,1771588821,2,'BE',1,0,15,'tx_themecamino_list_item','{\"oldRecord\":{\"link\":\"t3:\\/\\/page?uid=1\"},\"newRecord\":{\"link\":\"https:\\/\\/www.andersundsehr.com\\/impressum\"}}',0,'0400$a54232e2b1367d7a7e907078115a752f:0e96270cc28b0e0448e8c8d3bf6087ec'),
(45,1771588821,2,'BE',1,0,17,'tx_themecamino_list_item','{\"oldRecord\":{\"link\":\"t3:\\/\\/page?uid=1\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"link\":\"https:\\/\\/www.andersundsehr.com\\/datenschutzhinweis\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$a54232e2b1367d7a7e907078115a752f:cdce7c684835f1aff41674d980a594c4'),
(46,1771588821,4,'BE',1,0,16,'tx_themecamino_list_item',NULL,0,'0400$a54232e2b1367d7a7e907078115a752f:e341eebdf1a80bbe5c2280ad0071cbfd'),
(47,1771588848,2,'BE',1,0,11,'tx_themecamino_list_item','{\"oldRecord\":{\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/storybook\",\"link_label\":\"EXT:storybook\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"link\":\"https:\\/\\/www.andersundsehr.com\\/landing-pages\\/KI-Chatbot\",\"link_label\":\"Bumblebee - der KI-Chatbot\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$01b09fcdeb69be6d65a34cc9399947c8:fac8d56653c7e446ea9b5b9f3a3630fe'),
(48,1771588861,2,'BE',1,0,5,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$2502b345067899e021ddf2edfa87f091:553a0b94d31bc6d75a24b3146e82c7b9'),
(49,1771588861,2,'BE',1,0,7,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$2502b345067899e021ddf2edfa87f091:c42cb0131c55877d6432782967a88164'),
(50,1771588861,2,'BE',1,0,6,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$2502b345067899e021ddf2edfa87f091:a29cdb6aa8f1e8ff8bf21ca01298a2a5'),
(51,1771588888,2,'BE',1,0,14,'tx_themecamino_list_item','{\"oldRecord\":{\"link\":\"https:\\/\\/github.com\\/andersundsehr\",\"link_label\":\"https:\\/\\/github.com\\/andersundsehr\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"link\":\"https:\\/\\/github.com\\/webdevops\\/Dockerfile\",\"link_label\":\"webdevops\\/php\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$bf5a9088d422c4630d5a72cdf9fe70f0:d00d327965770bf21b1db955767c244b'),
(52,1771588892,2,'BE',1,0,7,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":4},\"newRecord\":{\"tx_themecamino_list_elements\":3}}',0,'0400$5f8379c0de39a20fc384f9d15e58188e:ea41b626baac59a1fe0716bc344af5d9'),
(53,1771588892,2,'BE',1,0,11,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$5f8379c0de39a20fc384f9d15e58188e:fac8d56653c7e446ea9b5b9f3a3630fe'),
(54,1771588892,4,'BE',1,0,12,'tx_themecamino_list_item',NULL,0,'0400$5f8379c0de39a20fc384f9d15e58188e:33a5acd1e8390d67d0bf39f5ec009db0'),
(55,1771588906,2,'BE',1,0,5,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":3},\"newRecord\":{\"tx_themecamino_list_elements\":2}}',0,'0400$e880f2dc5c35523de7baf2aef32d2efe:c7626fc9bcba6f70beb6ebc085a400db'),
(56,1771588906,4,'BE',1,0,6,'tx_themecamino_list_item',NULL,0,'0400$e880f2dc5c35523de7baf2aef32d2efe:a29cdb6aa8f1e8ff8bf21ca01298a2a5'),
(57,1771588965,2,'BE',1,0,8,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$8468871d5bc37e3fa6243523371b34aa:61d4a0fd373c5c9c133848e4e4d98b45'),
(58,1771588965,1,'BE',1,0,18,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/grumphp-config\",\"link_label\":\"\",\"sys_language_uid\":0,\"crdate\":1771588965,\"t3ver_stage\":0,\"tstamp\":1771588965,\"uid\":18}',0,'0400$8468871d5bc37e3fa6243523371b34aa:0dce8909c9bb0314b88774bb759d2987'),
(59,1771588965,4,'BE',1,0,10,'tx_themecamino_list_item',NULL,0,'0400$8468871d5bc37e3fa6243523371b34aa:e94df647818cf75d345ec41f8addf24c'),
(60,1771588965,4,'BE',1,0,9,'tx_themecamino_list_item',NULL,0,'0400$8468871d5bc37e3fa6243523371b34aa:e5291482bfd8fb9250717d6978c85a9d'),
(61,1771588977,1,'BE',1,0,19,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/grumphp-config\",\"link_label\":\"pkg:andersundsehr\\/grumphp-config\",\"sys_language_uid\":0,\"crdate\":1771588977,\"t3ver_stage\":0,\"tstamp\":1771588977,\"uid\":19}',0,'0400$cb6290d2277cb573aab3bfa989ef01e8:3d37a3c28514fc65d40b301d0b60b024'),
(62,1771588993,2,'BE',1,0,18,'tx_themecamino_list_item','{\"oldRecord\":{\"link_label\":\"\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"link_label\":\"Bumblebee - der KI-Chatbot\",\"l10n_diffsource\":\"{\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$7e7811637e5406df62c8c9174082c381:0dce8909c9bb0314b88774bb759d2987'),
(63,1771589000,2,'BE',1,0,11,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$30290e688c407828512672889b5b833f:fac8d56653c7e446ea9b5b9f3a3630fe'),
(64,1771589000,2,'BE',1,0,13,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$30290e688c407828512672889b5b833f:0f1fa0fa151eb565f5e8d354a5f5cea8'),
(65,1771589000,2,'BE',1,0,14,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$30290e688c407828512672889b5b833f:d00d327965770bf21b1db955767c244b'),
(66,1771589006,2,'BE',1,0,7,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":3},\"newRecord\":{\"tx_themecamino_list_elements\":2}}',0,'0400$58986222b9d86a88641c83607e6330b7:ea41b626baac59a1fe0716bc344af5d9'),
(67,1771589006,2,'BE',1,0,13,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$58986222b9d86a88641c83607e6330b7:0f1fa0fa151eb565f5e8d354a5f5cea8'),
(68,1771589006,4,'BE',1,0,11,'tx_themecamino_list_item',NULL,0,'0400$58986222b9d86a88641c83607e6330b7:fac8d56653c7e446ea9b5b9f3a3630fe'),
(69,1771589012,2,'BE',1,0,8,'tx_themecamino_list_item','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$7f14fe4d7539bb09a72e837ba22e987a:61d4a0fd373c5c9c133848e4e4d98b45'),
(70,1771589012,2,'BE',1,0,18,'tx_themecamino_list_item','{\"oldRecord\":{\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/grumphp-config\",\"l10n_diffsource\":\"{\\\"link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"link\":\"https:\\/\\/www.andersundsehr.com\\/landing-pages\\/KI-Chatbot\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$7f14fe4d7539bb09a72e837ba22e987a:0dce8909c9bb0314b88774bb759d2987'),
(71,1771589034,2,'BE',1,0,8,'tx_themecamino_list_item','{\"oldRecord\":{\"link_label\":\"https:\\/\\/github.com\\/andersundsehr\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"link_label\":\"github.com\\/andersundsehr\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$447d415c827d5ca151a8a686f0bf0910:61d4a0fd373c5c9c133848e4e4d98b45'),
(72,1771589045,2,'BE',1,0,19,'tx_themecamino_list_item','{\"oldRecord\":{\"link_label\":\"pkg:andersundsehr\\/grumphp-config\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"link_label\":\"pkg:grumphp-config\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\"}\"}}',0,'0400$12012ca908a9be5fcc1de00ec423b68b:3d37a3c28514fc65d40b301d0b60b024'),
(73,1771589092,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":0,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":1,\"sys_language_uid\":1,\"l10n_parent\":\"1\",\"l10n_source\":1,\"title\":\"Home\",\"nav_hide\":0,\"no_search\":0,\"shortcut\":0,\"shortcut_mode\":\"0\",\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"mount_pid\":0,\"is_siteroot\":1,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__CaminoStartpage\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\",\\\"tx_themecamino_logo\\\":\\\"parent\\\"}\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__CaminoStartpage\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"1\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Home\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"tx_themecamino_logo\\\":\\\"0\\\"}\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":2}',0,'0400$32aa0bb41dea46cdee54c8334f0fbb3a:f11830df10b4b0bca2db34810c2241b3'),
(74,1771589092,1,'BE',1,0,2,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":\"1\",\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"{\\\\\\\"default\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":1,\\\\\\\"width\\\\\\\":0.996,\\\\\\\"x\\\\\\\":0.003,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"16:9\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false},\\\\\\\"sm\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":1,\\\\\\\"width\\\\\\\":0.6,\\\\\\\"x\\\\\\\":0.399,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"16:15\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false},\\\\\\\"md\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":1,\\\\\\\"width\\\\\\\":0.75,\\\\\\\"x\\\\\\\":0.249,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"4:3\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false},\\\\\\\"lg\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":1,\\\\\\\"width\\\\\\\":0.844,\\\\\\\"x\\\\\\\":0.155,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"3:2\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false},\\\\\\\"xl\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":0.8880994671403197,\\\\\\\"width\\\\\\\":1,\\\\\\\"x\\\\\\\":0,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"2:1\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false}}\\\",\\\"description\\\":\\\"\\\",\\\"fieldname\\\":\\\"image\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tt_content\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"2\\\",\\\"uid_local\\\":\\\"2\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_state\":null,\"uid_local\":\"2\",\"uid_foreign\":2,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.996,\\\"x\\\":0.003,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.6,\\\"x\\\":0.399,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:15\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.75,\\\"x\\\":0.249,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"4:3\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.844,\\\"x\\\":0.155,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"height\\\":0.8880994671403197,\\\"width\\\":1,\\\"x\\\":0,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"2:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":2}',0,'0400$efcaa2f8602258fdb691b3e758849898:814fc0f720dfab882655a795e23a5b66'),
(75,1771589092,1,'BE',1,0,9,'tt_content','{\"CType\":\"camino_hero_small\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":\"2\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":384,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":2,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_hero_small\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"2\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"New Look, New Feel\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"1\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"A fresh foundation for every project\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"https:\\\\\\/\\\\\\/github.com\\\\\\/andersundsehr\\\\\\/visual_editor\\\",\\\"tx_themecamino_link_config\\\":\\\"0\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"Read more\\\",\\\"tx_themecamino_list_elements\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"frame_class\":\"default\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"header\":\"New Look, New Feel\",\"header_link\":\"\",\"subheader\":\"A fresh foundation for every project\",\"bodytext\":null,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"https:\\/\\/github.com\\/andersundsehr\\/visual_editor\",\"tx_themecamino_link_label\":\"Read more\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":9}',0,'0400$424c9c3c230a470653a03fa09f2d012f:367f4f227870d8e2a11496a182574aa3'),
(76,1771589092,1,'BE',1,0,10,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":\"3\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":192,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":3,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"text\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"<p>Edit content directly where it\'s created: on the page. No more form streaks or tab hopping \\\\u2014 just click, tap, and you\'re done. <strong>What you see is what you ship:<\\\\\\/strong> <a href=\\\\\\\"t3:\\\\\\/\\\\\\/page?uid=15\\\\\\\">headlines<\\\\\\/a>, teasers, and CTAs update in context, so teams move faster, make fewer mistakes, and need less back-and-forth.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Visual Editing f\\\\u00fcr TYPO3\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"Because it is just natural that way.\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"0\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"Visual Editing f\\u00fcr TYPO3\",\"header_link\":\"\",\"subheader\":\"Because it is just natural that way.\",\"bodytext\":\"<p>Edit content directly where it\'s created: on the page. No more form streaks or tab hopping \\u2014 just click, tap, and you\'re done. <strong>What you see is what you ship:<\\/strong> <a href=\\\"t3:\\/\\/page?uid=15\\\">headlines<\\/a>, teasers, and CTAs update in context, so teams move faster, make fewer mistakes, and need less back-and-forth.<\\/p>\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":10}',0,'0400$95f7a31a0cdf6c1182511d4f7e61e609:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(77,1771589092,1,'BE',1,0,11,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":\"1\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":224,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":1,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"text\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"<h2>\\\\ud83d\\\\ude80 Publish faster<\\\\\\/h2>\\\\r\\\\n<p>Small changes (headlines, teasers, CTA copy) take seconds instead of minutes.<\\\\\\/p>\\\\r\\\\n<h2>\\\\ud83c\\\\udfaf Fewer errors, less back-and-forth<\\\\\\/h2>\\\\r\\\\n<p>Edits happen in layout context \\\\u2014 fewer \\\\u201cOops, wrong content block\\\\u201d moments.<\\\\\\/p>\\\\r\\\\n<h2>\\\\ud83e\\\\udde0 Less training required<\\\\\\/h2>\\\\r\\\\n<p>Editors get it instantly: click = edit.<\\\\\\/p>\\\\r\\\\n<h2>\\\\ud83e\\\\udde9 Built for TYPO3<\\\\\\/h2>\\\\r\\\\n<p>No foreign layer, no \\\\u201csecond CMS\\\\u201d. Cleanly integrated into the TYPO3 ecosystem.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Benefits\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"Benefits\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<h2>\\ud83d\\ude80 Publish faster<\\/h2>\\r\\n<p>Small changes (headlines, teasers, CTA copy) take seconds instead of minutes.<\\/p>\\r\\n<h2>\\ud83c\\udfaf Fewer errors, less back-and-forth<\\/h2>\\r\\n<p>Edits happen in layout context \\u2014 fewer \\u201cOops, wrong content block\\u201d moments.<\\/p>\\r\\n<h2>\\ud83e\\udde0 Less training required<\\/h2>\\r\\n<p>Editors get it instantly: click = edit.<\\/p>\\r\\n<h2>\\ud83e\\udde9 Built for TYPO3<\\/h2>\\r\\n<p>No foreign layer, no \\u201csecond CMS\\u201d. Cleanly integrated into the TYPO3 ecosystem.<\\/p>\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":11}',0,'0400$88e91bbd9e1d2b5f7adff1778cf69b57:7a14c618500ae24604910dfdd2f8ff12'),
(78,1771589092,1,'BE',1,0,20,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":\"1\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/www.instagram.com\\\\\\/anders.und.sehr\\\\\\/\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"4\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":1,\"l10n_state\":null,\"uid_foreign\":\"4\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/www.instagram.com\\/anders.und.sehr\\/\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":20}',0,'0400$9591568ff87591236b584b31383a1043:b616b5e7c1cf4ce27ca04f57d961da48'),
(79,1771589092,1,'BE',1,0,21,'tx_themecamino_list_item','{\"sorting_foreign\":514,\"hidden\":0,\"l10n_parent\":\"2\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/www.facebook.com\\\\\\/andersundsehr\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"514\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"4\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":2,\"l10n_state\":null,\"uid_foreign\":\"4\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/www.facebook.com\\/andersundsehr\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":21}',0,'0400$3dd1d1b1e439290a1891d129d82dbecb:cea0ec5dbaef45271896ebd4bfbfac07'),
(80,1771589092,1,'BE',1,0,22,'tx_themecamino_list_item','{\"sorting_foreign\":1000,\"hidden\":0,\"l10n_parent\":\"3\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/de.linkedin.com\\\\\\/company\\\\\\/anders-und-sehr\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"1027\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"4\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":3,\"l10n_state\":null,\"uid_foreign\":\"4\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/de.linkedin.com\\/company\\/anders-und-sehr\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":22}',0,'0400$309e1422cd172d3dcc3e5ab89e543437:754726d6e221798af0ed8caa6528598a'),
(81,1771589092,1,'BE',1,0,23,'tx_themecamino_list_item','{\"sorting_foreign\":1000,\"hidden\":0,\"l10n_parent\":\"4\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/www.xing.com\\\\\\/pages\\\\\\/andersundsehrgmbh\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"1540\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"4\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":4,\"l10n_state\":null,\"uid_foreign\":\"4\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/www.xing.com\\/pages\\/andersundsehrgmbh\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":23}',0,'0400$44dcf7c5353b1c661f9267ac61a032e7:25a5f85696d228dd920189f9cd3a4d3c'),
(82,1771589092,1,'BE',1,0,12,'tt_content','{\"CType\":\"camino_sociallinks\",\"colPos\":\"11\",\"l18n_parent\":\"4\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":96,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":4,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_sociallinks\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"11\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"4\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"frame_class\":\"default\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"\",\"header_layout\":\"0\",\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_header_style\":\"0\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":12}',0,'0400$032acde7c50eff542fe41b7720f2e5c3:b13bbccfb8e2fc277be02db62485ced6'),
(83,1771589092,1,'BE',1,0,24,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":\"5\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/github.com\\\\\\/andersundsehr\\\\\\/aus_driver_amazon_s3\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"ET:aus_driver_amazon_s3\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"5\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":5,\"l10n_state\":null,\"uid_foreign\":\"5\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/aus_driver_amazon_s3\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"ET:aus_driver_amazon_s3\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":24}',0,'0400$0e5b9b00d98225990af643e3f659a432:c5d1fee609b0651562760e73e301348d'),
(84,1771589092,1,'BE',1,0,25,'tx_themecamino_list_item','{\"sorting_foreign\":1000,\"hidden\":0,\"l10n_parent\":\"7\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/github.com\\\\\\/andersundsehr\\\\\\/storybook\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"EXT:storybook\\\",\\\"sorting_foreign\\\":\\\"1026\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"5\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":7,\"l10n_state\":null,\"uid_foreign\":\"5\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/storybook\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"EXT:storybook\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":25}',0,'0400$17e7d8caea2915b6f15b98d1649d7500:e83833c8974078690459d4d9e4cd10da'),
(85,1771589092,1,'BE',1,0,26,'tx_themecamino_list_item','{\"sorting_foreign\":1000,\"hidden\":0,\"l10n_parent\":\"19\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/github.com\\\\\\/andersundsehr\\\\\\/grumphp-config\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"pkg:grumphp-config\\\",\\\"sorting_foreign\\\":\\\"2051\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"5\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":19,\"l10n_state\":null,\"uid_foreign\":\"5\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/grumphp-config\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"pkg:grumphp-config\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":26}',0,'0400$cb487d84b532075df5a6eb1356ce2fd6:5ead5ddf079188124c3610651e069529'),
(86,1771589092,1,'BE',1,0,13,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"12\",\"l18n_parent\":\"5\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":48,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":5,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_linklist\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"12\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"3\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"frame_class\":\"default\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"\",\"header_layout\":\"0\",\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_header_style\":\"0\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":13}',0,'0400$1eb46feeef5df2bdd81388199c54d0ae:aa58d78b4f5fe95c0d2d1cb36d041737'),
(87,1771589092,1,'BE',1,0,27,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":\"18\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/www.andersundsehr.com\\\\\\/landing-pages\\\\\\/KI-Chatbot\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"Bumblebee - der KI-Chatbot\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"6\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":18,\"l10n_state\":null,\"uid_foreign\":\"6\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/www.andersundsehr.com\\/landing-pages\\/KI-Chatbot\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Bumblebee - der KI-Chatbot\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":27}',0,'0400$1b1b004fbc2dd99484a93dd5bde3a764:8dcc28552b6711250ea1c2d00aa77ef9'),
(88,1771589092,1,'BE',1,0,28,'tx_themecamino_list_item','{\"sorting_foreign\":1000,\"hidden\":0,\"l10n_parent\":\"8\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/github.com\\\\\\/andersundsehr\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"github.com\\\\\\/andersundsehr\\\",\\\"sorting_foreign\\\":\\\"1538\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"6\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":8,\"l10n_state\":null,\"uid_foreign\":\"6\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/github.com\\/andersundsehr\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"github.com\\/andersundsehr\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":28}',0,'0400$fb495fc6d3e7845f29888d1125bef2a5:1b17791b29756a01cf546e7a12b1a834'),
(89,1771589092,1,'BE',1,0,14,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"13\",\"l18n_parent\":\"6\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":24,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":6,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_linklist\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"13\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"2\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"frame_class\":\"default\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"\",\"header_layout\":\"0\",\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_header_style\":\"0\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":14}',0,'0400$b8ec642d5af227e02f8019a6a67fd816:338e104baa774eacaec42da729015b5f'),
(90,1771589092,1,'BE',1,0,29,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":\"14\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/github.com\\\\\\/webdevops\\\\\\/Dockerfile\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"webdevops\\\\\\/php\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"7\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":14,\"l10n_state\":null,\"uid_foreign\":\"7\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/github.com\\/webdevops\\/Dockerfile\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"webdevops\\/php\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":29}',0,'0400$b568ebb8ba1b82d120643c7397319f54:d49748646f7bc6dde699d6d7634c23b3'),
(91,1771589092,1,'BE',1,0,30,'tx_themecamino_list_item','{\"sorting_foreign\":1000,\"hidden\":0,\"l10n_parent\":\"13\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"http:\\\\\\/\\\\\\/github.com\\\\\\/pluswerk\\\\\\/php-dev\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"php-dev\\\",\\\"sorting_foreign\\\":\\\"2562\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"7\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":13,\"l10n_state\":null,\"uid_foreign\":\"7\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"http:\\/\\/github.com\\/pluswerk\\/php-dev\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"php-dev\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":30}',0,'0400$dc9f7f164fdc6e371786917c0d298528:3b40bafe94418ca4c56a7016bd115f04'),
(92,1771589092,1,'BE',1,0,15,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"14\",\"l18n_parent\":\"7\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":12,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":7,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_linklist\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"14\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"2\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"frame_class\":\"default\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"\",\"header_layout\":\"0\",\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_header_style\":\"0\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":15}',0,'0400$2bbe06ca0acc8d8505eb6ec33caffa4b:cb118fde3da18e67b21a92b60bb8cbda'),
(93,1771589092,1,'BE',1,0,31,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":\"15\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/www.andersundsehr.com\\\\\\/impressum\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"Impressum\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"8\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":15,\"l10n_state\":null,\"uid_foreign\":\"8\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/www.andersundsehr.com\\/impressum\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Impressum\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":31}',0,'0400$e58aa5da8e6f287aa9251e9564f16cd7:fb322a073ee1aef7c8bf964efa7687f0'),
(94,1771589092,1,'BE',1,0,32,'tx_themecamino_list_item','{\"sorting_foreign\":1000,\"hidden\":0,\"l10n_parent\":\"17\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/www.andersundsehr.com\\\\\\/datenschutzhinweis\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"Datenschutzhinwei\\\\u00df\\\",\\\"sorting_foreign\\\":\\\"3586\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"8\\\"}\",\"pid\":1,\"sys_language_uid\":1,\"l10n_source\":17,\"l10n_state\":null,\"uid_foreign\":\"8\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/www.andersundsehr.com\\/datenschutzhinweis\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Datenschutzhinwei\\u00df\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":32}',0,'0400$885de6be6878290e408d4c6bb6e99ace:77e9fa87867c4a7ba3aaaf6de3822d69'),
(95,1771589092,1,'BE',1,0,16,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"10\",\"l18n_parent\":\"8\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":6,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":8,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_linklist\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"10\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Footer\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"2\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"frame_class\":\"default\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"Footer\",\"header_layout\":\"0\",\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_header_style\":\"0\",\"crdate\":1771589092,\"t3ver_stage\":0,\"tstamp\":1771589092,\"uid\":16}',0,'0400$fd9ea28d60171486ed3db2c9211455a8:43f02d513e41a72738b96558f7ee9015'),
(96,1771589096,2,'BE',1,0,9,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$ae962879c8ac602a419f476a8eadfb93:367f4f227870d8e2a11496a182574aa3'),
(97,1771589097,2,'BE',1,0,10,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$81f26410f0608a7ee97d49f9db782f0a:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(98,1771589098,2,'BE',1,0,11,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$21056d5850df3fdab826d77756acdc3e:7a14c618500ae24604910dfdd2f8ff12'),
(99,1771589099,2,'BE',1,0,15,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$5dc070a2a06f004b8a56de43b4e2feae:cb118fde3da18e67b21a92b60bb8cbda'),
(100,1771589100,2,'BE',1,0,14,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$b2291c835772664f3310c6ec05130080:338e104baa774eacaec42da729015b5f'),
(101,1771589101,2,'BE',1,0,13,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$efd21309c6dbec34363e5814378ff28d:aa58d78b4f5fe95c0d2d1cb36d041737'),
(102,1771589101,2,'BE',1,0,12,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$9f264d177733e4db72d073af57cc691f:b13bbccfb8e2fc277be02db62485ced6'),
(103,1771589103,2,'BE',1,0,16,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$14541be0188f5cf6172e7ef6c23dcdfd:43f02d513e41a72738b96558f7ee9015'),
(104,1771589159,2,'BE',1,0,9,'tt_content','{\"oldRecord\":{\"subheader\":\"A fresh foundation for every project\"},\"newRecord\":{\"subheader\":\"Eine neue Basis f\\u00fcr jedes Projekt\"}}',0,'0400$73458b035783e126b7436eee9e5f295d:367f4f227870d8e2a11496a182574aa3'),
(105,1771589169,2,'BE',1,0,9,'tt_content','{\"oldRecord\":{\"tx_themecamino_link_label\":\"Read more\"},\"newRecord\":{\"tx_themecamino_link_label\":\"Mehr lesen\"}}',0,'0400$8423735a32256360f4c65f841499cdb1:367f4f227870d8e2a11496a182574aa3'),
(106,1771589179,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Visual Editing f\\u00fcr TYPO3\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Visual Editing for TYPO3\",\"l18n_diffsource\":\"{\\\"header\\\":\\\"\\\"}\"}}',0,'0400$213f2d769a7a4e96da7281e9d92a956a:b92300cfb5d1d3645c9cb212a7f56c1f'),
(107,1771589265,2,'BE',1,0,10,'tt_content','{\"oldRecord\":{\"subheader\":\"Because it is just natural that way.\",\"bodytext\":\"<p>Edit content directly where it\'s created: on the page. No more form streaks or tab hopping \\u2014 just click, tap, and you\'re done. <strong>What you see is what you ship:<\\/strong> <a href=\\\"t3:\\/\\/page?uid=15\\\">headlines<\\/a>, teasers, and CTAs update in context, so teams move faster, make fewer mistakes, and need less back-and-forth.<\\/p>\"},\"newRecord\":{\"subheader\":\"Weil es einfach so nat\\u00fcrlich ist.\",\"bodytext\":\"<p>Bearbeiten Sie Inhalte direkt dort, wo sie erstellt werden: auf der Seite.&nbsp;<br \\/>Keine Formularfelder oder Tab-Wechsel mehr \\u2013 einfach klicken, tippen und fertig.&nbsp;<br \\/><strong>Was Sie sehen, ist es, was Sie ver\\u00f6ffentlichen:<\\/strong> \\u00dcberschriften, Teaser und <a href=\\\"t3:\\/\\/page?uid=1\\\">CTAs <\\/a>werden im Kontext aktualisiert, sodass Teams schneller arbeiten, weniger Fehler machen und weniger Hin und Her ben\\u00f6tigen.<\\/p>\"}}',0,'0400$ab67098ba2acfa8a2f20e03ab2dd2dd0:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(108,1771589302,2,'BE',1,0,11,'tt_content','{\"oldRecord\":{\"header\":\"Benefits\",\"bodytext\":\"<h2>\\ud83d\\ude80 Publish faster<\\/h2>\\r\\n<p>Small changes (headlines, teasers, CTA copy) take seconds instead of minutes.<\\/p>\\r\\n<h2>\\ud83c\\udfaf Fewer errors, less back-and-forth<\\/h2>\\r\\n<p>Edits happen in layout context \\u2014 fewer \\u201cOops, wrong content block\\u201d moments.<\\/p>\\r\\n<h2>\\ud83e\\udde0 Less training required<\\/h2>\\r\\n<p>Editors get it instantly: click = edit.<\\/p>\\r\\n<h2>\\ud83e\\udde9 Built for TYPO3<\\/h2>\\r\\n<p>No foreign layer, no \\u201csecond CMS\\u201d. Cleanly integrated into the TYPO3 ecosystem.<\\/p>\"},\"newRecord\":{\"header\":\"Vorteile\",\"bodytext\":\"<h2>\\ud83d\\ude80 Schneller ver\\u00f6ffentlichen<\\/h2>\\r\\n<p>Kleine \\u00c4nderungen (\\u00dcberschriften, Teaser, CTA-Texte) dauern nur Sekunden statt Minuten.<\\/p>\\r\\n<h2>\\ud83c\\udfaf Weniger Fehler, weniger Hin und Her<\\/h2>\\r\\n<p>Bearbeitungen erfolgen im Layout-Kontext \\u2013 weniger \\u201eHoppla, falscher Inhaltsblock\\u201c-Momente.<\\/p>\\r\\n<h2>\\ud83e\\udde0 Weniger Schulungsaufwand<\\/h2>\\r\\n<p>Redakteure verstehen es sofort: Klicken = bearbeiten.<\\/p>\\r\\n<h2>\\ud83e\\udde9 Entwickelt f\\u00fcr TYPO3<\\/h2>\\r\\n<p>Keine fremde Ebene, kein \\u201ezweites CMS\\u201c. Sauber in das TYPO3-\\u00d6kosystem integriert.<\\/p>\"}}',0,'0400$b3e583edc02db5ef410ced8b522a3c52:7a14c618500ae24604910dfdd2f8ff12'),
(109,1771589318,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__CaminoStartpage\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"1\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Home\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"tx_themecamino_logo\\\":\\\"0\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__CaminoStartpage\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"1\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"0\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Home\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"0\\\"}\"}}',0,'0400$a73cf2a99076d0ac2f1d6e3f97ea9a29:f11830df10b4b0bca2db34810c2241b3'),
(110,1771589325,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout_next_level\":\"\"},\"newRecord\":{\"backend_layout_next_level\":\"pagets__CaminoContentpageSidebar\"}}',0,'0400$8be56c6d82242b330839f604fdc61709:e175f7045d7ccbfb26ffcf279422c2e5'),
(111,1771589325,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout_next_level\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__CaminoStartpage\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"1\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"0\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Home\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"0\\\"}\"},\"newRecord\":{\"backend_layout_next_level\":\"pagets__CaminoContentpageSidebar\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__CaminoStartpage\\\",\\\"backend_layout_next_level\\\":\\\"pagets__CaminoContentpageSidebar\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"1\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"0\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Home\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"0\\\"}\"}}',0,'0400$8be56c6d82242b330839f604fdc61709:f11830df10b4b0bca2db34810c2241b3'),
(112,1771589332,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/about-us\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"About us\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\",\"crdate\":1771589332,\"t3ver_stage\":0,\"tstamp\":1771589332,\"uid\":3}',0,'0400$84d4be6b1770e809974177af90ded3c9:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(113,1771589343,1,'BE',1,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/about-us\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_parent\":\"3\",\"l10n_source\":3,\"title\":\"About us\",\"nav_hide\":0,\"no_search\":0,\"shortcut\":0,\"shortcut_mode\":\"0\",\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"mount_pid\":0,\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\",\\\"tx_themecamino_logo\\\":\\\"parent\\\"}\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"1\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/about-us\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"About us\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"tx_themecamino_logo\\\":\\\"0\\\"}\",\"crdate\":1771589343,\"t3ver_stage\":0,\"tstamp\":1771589343,\"uid\":4}',0,'0400$4dabf7d8d327b48b565c0cb5d96afc30:412add0b3eb6ec8f1cb6710aea92e21e'),
(114,1771589348,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$f9f184cd4946d7ba4d3934f6fd66858b:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(115,1771589351,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"1\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/about-us\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"About us\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"tx_themecamino_logo\\\":\\\"0\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"0\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/about-us\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"About us\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"0\\\"}\"}}',0,'0400$00d5b2d5b88d978bd031700a1ff1964b:412add0b3eb6ec8f1cb6710aea92e21e'),
(116,1771589455,1,'BE',1,0,17,'tt_content','{\"CType\":\"camino_author\",\"colPos\":\"1\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":3,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"Matthias Vogel\",\"subheader\":\"Technical Leader\",\"bodytext\":\"Maintainer of:\\r\\n- EXT:visual_editor\\r\\n- EXT:storybook\\r\\n- webdevops\\/php\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1771589455,\"t3ver_stage\":0,\"tstamp\":1771589455,\"uid\":17}',0,'0400$3e43a1a99a5e4e397c7df64212bc1119:017157395cc6da9e5d2911de6dfd4b9e'),
(117,1771589455,1,'BE',1,0,3,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.0024630541871921183,\\\"width\\\":1,\\\"height\\\":0.9950738916256158},\\\"selectedRatio\\\":\\\"1:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"3\",\"sys_language_uid\":0,\"crdate\":1771589455,\"t3ver_stage\":0,\"tstamp\":1771589455,\"uid\":3}',0,'0400$3e43a1a99a5e4e397c7df64212bc1119:d2c609347a4764200256b39b9425159a'),
(118,1771589455,1,'BE',1,0,33,'tx_themecamino_list_item','{\"sorting_foreign\":256,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"https:\\/\\/mastodontech.de\\/@kanti\",\"link_label\":\"Mastodon\",\"sys_language_uid\":0,\"crdate\":1771589455,\"t3ver_stage\":0,\"tstamp\":1771589455,\"uid\":33}',0,'0400$3e43a1a99a5e4e397c7df64212bc1119:81572761d685d5a6ad86ebab16d24d20'),
(119,1771589455,1,'BE',1,0,34,'tx_themecamino_list_item','{\"sorting_foreign\":128,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"https:\\/\\/typo3.slack.com\\/team\\/U046M1E1J\",\"link_label\":\"TYPO3 Slack\",\"sys_language_uid\":0,\"crdate\":1771589455,\"t3ver_stage\":0,\"tstamp\":1771589455,\"uid\":34}',0,'0400$3e43a1a99a5e4e397c7df64212bc1119:6231cef43998a85b46e83d2b918d01c9'),
(120,1771589511,1,'BE',1,0,18,'tt_content','{\"CType\":\"camino_hero_small\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":3,\"sorting\":128,\"sys_language_uid\":0,\"header\":\"\",\"subheader\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_config\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1771589511,\"t3ver_stage\":0,\"tstamp\":1771589511,\"uid\":18}',0,'0400$4b4fdaa06f16501092c79a4c772df590:0a64be1ae1f9096cc345beb76e5e2095'),
(121,1771589511,1,'BE',1,0,4,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.996,\\\"x\\\":0.002,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.6,\\\"x\\\":0.334,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:15\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.75,\\\"x\\\":0.189,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"4:3\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.844,\\\"x\\\":0.099,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"height\\\":0.8880994671403197,\\\"width\\\":1,\\\"x\\\":0,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"2:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"4\",\"sys_language_uid\":0,\"crdate\":1771589511,\"t3ver_stage\":0,\"tstamp\":1771589511,\"uid\":4}',0,'0400$4b4fdaa06f16501092c79a4c772df590:cea5fcd7b97871880cfe3717d6b52ef4'),
(122,1771589727,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"title\":\"About us\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"title\":\"Agentur\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"}}',0,'0400$27d5a6c8e4049d147669688c36a28734:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(123,1771589733,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"title\":\"Agentur\"},\"newRecord\":{\"title\":\"Agency\"}}',0,'0400$5d3535eeb5903c3e785e22e64274bd3c:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(124,1771589738,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"title\":\"Agency\"},\"newRecord\":{\"title\":\"About Us\"}}',0,'0400$6b2960b5d190b20101537f5aa1d7cb3e:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(125,1771589750,1,'BE',1,0,19,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":3,\"sorting\":64,\"sys_language_uid\":0,\"header\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>We\\u2019re <strong>anders und sehr<\\/strong>, a Stuttgart-based 360\\u00b0 digital agency bringing together <strong>concept &amp; design<\\/strong>, <strong>branding &amp; marketing<\\/strong>, and <strong>development &amp; technology<\\/strong> under one roof.<\\/p>\\r\\n<p>Thinking differently is part of our DNA. We shift perspectives, question assumptions, and explore unconventional routes with curiosity\\u2014while staying grounded, so we don\\u2019t have to gamble later when it\\u2019s time to ship.<\\/p>\\r\\n<p>We call ourselves <strong>digital architects<\\/strong> for a reason: great digital work needs a beautiful fa\\u00e7ade <i>and<\\/i> a stable foundation. That\\u2019s why we start with strategy and concept, then design, build, and deliver a solution that works as a coherent whole. We build everything\\u2014just not castles in the air.<\\/p>\\r\\n<p>What makes us different? <strong>Ideas.<\\/strong> Even a small one can have a big impact when it\\u2019s unique and hits the nerve of your audience. We see ourselves as explorers and pioneers\\u2014turning ideas into business value without chasing every trend.<\\/p>\\r\\n<p>Behind it all is a team that\\u2019s diverse, a little wild in the best way, and fiercely loyal to clients, craft, and each other. After 25 years and 28+ minds, we\\u2019re still hungry for the next perspective.<\\/p>\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_config\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1771589750,\"t3ver_stage\":0,\"tstamp\":1771589750,\"uid\":19}',0,'0400$b4c3a1edc2e997bff083dc48458553d1:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(126,1771589810,1,'BE',1,0,5,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":\"4\",\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"{\\\\\\\"default\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":1,\\\\\\\"width\\\\\\\":0.996,\\\\\\\"x\\\\\\\":0.002,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"16:9\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false},\\\\\\\"sm\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":1,\\\\\\\"width\\\\\\\":0.6,\\\\\\\"x\\\\\\\":0.334,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"16:15\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false},\\\\\\\"md\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":1,\\\\\\\"width\\\\\\\":0.75,\\\\\\\"x\\\\\\\":0.189,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"4:3\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false},\\\\\\\"lg\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":1,\\\\\\\"width\\\\\\\":0.844,\\\\\\\"x\\\\\\\":0.099,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"3:2\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false},\\\\\\\"xl\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"height\\\\\\\":0.8880994671403197,\\\\\\\"width\\\\\\\":1,\\\\\\\"x\\\\\\\":0,\\\\\\\"y\\\\\\\":0},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"2:1\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false}}\\\",\\\"description\\\":\\\"\\\",\\\"fieldname\\\":\\\"image\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tt_content\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"18\\\",\\\"uid_local\\\":\\\"4\\\"}\",\"pid\":3,\"sys_language_uid\":1,\"l10n_state\":null,\"uid_local\":\"4\",\"uid_foreign\":18,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.996,\\\"x\\\":0.002,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.6,\\\"x\\\":0.334,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"16:15\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.75,\\\"x\\\":0.189,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"4:3\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"height\\\":1,\\\"width\\\":0.844,\\\"x\\\":0.099,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"height\\\":0.8880994671403197,\\\"width\\\":1,\\\"x\\\":0,\\\"y\\\":0},\\\"selectedRatio\\\":\\\"2:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1771589810,\"t3ver_stage\":0,\"tstamp\":1771589810,\"uid\":5}',0,'0400$1c21378d5484b97932a58e58622a25b3:5f15a1453f67b933ed3314381f5d67e4'),
(127,1771589810,1,'BE',1,0,20,'tt_content','{\"CType\":\"camino_hero_small\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":\"18\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":3,\"sorting\":192,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":18,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_hero_small\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"2\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"1\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"0\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"frame_class\":\"default\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"crdate\":1771589810,\"t3ver_stage\":0,\"tstamp\":1771589810,\"uid\":20}',0,'0400$1382196dee1e53bbac4e54a58f8c451d:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(128,1771589810,1,'BE',1,0,21,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":\"19\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":3,\"sorting\":96,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":19,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"text\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"<p>We\\\\u2019re <strong>anders und sehr<\\\\\\/strong>, a Stuttgart-based 360\\\\u00b0 digital agency bringing together <strong>concept &amp; design<\\\\\\/strong>, <strong>branding &amp; marketing<\\\\\\/strong>, and <strong>development &amp; technology<\\\\\\/strong> under one roof.<\\\\\\/p>\\\\r\\\\n<p>Thinking differently is part of our DNA. We shift perspectives, question assumptions, and explore unconventional routes with curiosity\\\\u2014while staying grounded, so we don\\\\u2019t have to gamble later when it\\\\u2019s time to ship.<\\\\\\/p>\\\\r\\\\n<p>We call ourselves <strong>digital architects<\\\\\\/strong> for a reason: great digital work needs a beautiful fa\\\\u00e7ade <i>and<\\\\\\/i> a stable foundation. That\\\\u2019s why we start with strategy and concept, then design, build, and deliver a solution that works as a coherent whole. We build everything\\\\u2014just not castles in the air.<\\\\\\/p>\\\\r\\\\n<p>What makes us different? <strong>Ideas.<\\\\\\/strong> Even a small one can have a big impact when it\\\\u2019s unique and hits the nerve of your audience. We see ourselves as explorers and pioneers\\\\u2014turning ideas into business value without chasing every trend.<\\\\\\/p>\\\\r\\\\n<p>Behind it all is a team that\\\\u2019s diverse, a little wild in the best way, and fiercely loyal to clients, craft, and each other. After 25 years and 28+ minds, we\\\\u2019re still hungry for the next perspective.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"0\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>We\\u2019re <strong>anders und sehr<\\/strong>, a Stuttgart-based 360\\u00b0 digital agency bringing together <strong>concept &amp; design<\\/strong>, <strong>branding &amp; marketing<\\/strong>, and <strong>development &amp; technology<\\/strong> under one roof.<\\/p>\\r\\n<p>Thinking differently is part of our DNA. We shift perspectives, question assumptions, and explore unconventional routes with curiosity\\u2014while staying grounded, so we don\\u2019t have to gamble later when it\\u2019s time to ship.<\\/p>\\r\\n<p>We call ourselves <strong>digital architects<\\/strong> for a reason: great digital work needs a beautiful fa\\u00e7ade <i>and<\\/i> a stable foundation. That\\u2019s why we start with strategy and concept, then design, build, and deliver a solution that works as a coherent whole. We build everything\\u2014just not castles in the air.<\\/p>\\r\\n<p>What makes us different? <strong>Ideas.<\\/strong> Even a small one can have a big impact when it\\u2019s unique and hits the nerve of your audience. We see ourselves as explorers and pioneers\\u2014turning ideas into business value without chasing every trend.<\\/p>\\r\\n<p>Behind it all is a team that\\u2019s diverse, a little wild in the best way, and fiercely loyal to clients, craft, and each other. After 25 years and 28+ minds, we\\u2019re still hungry for the next perspective.<\\/p>\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"crdate\":1771589810,\"t3ver_stage\":0,\"tstamp\":1771589810,\"uid\":21}',0,'0400$8be5f282edc00243b0c3b43f6d85b815:7fd72e21409e45562c51e7581fc2cb0d'),
(129,1771589810,1,'BE',1,0,6,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":\"3\",\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"{\\\\\\\"default\\\\\\\":{\\\\\\\"cropArea\\\\\\\":{\\\\\\\"x\\\\\\\":0,\\\\\\\"y\\\\\\\":0.0024630541871921183,\\\\\\\"width\\\\\\\":1,\\\\\\\"height\\\\\\\":0.9950738916256158},\\\\\\\"selectedRatio\\\\\\\":\\\\\\\"1:1\\\\\\\",\\\\\\\"focusArea\\\\\\\":null,\\\\\\\"excludeFromSync\\\\\\\":false}}\\\",\\\"description\\\":\\\"\\\",\\\"fieldname\\\":\\\"image\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tt_content\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"17\\\",\\\"uid_local\\\":\\\"3\\\"}\",\"pid\":3,\"sys_language_uid\":1,\"l10n_state\":null,\"uid_local\":\"3\",\"uid_foreign\":17,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.0024630541871921183,\\\"width\\\":1,\\\"height\\\":0.9950738916256158},\\\"selectedRatio\\\":\\\"1:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1771589810,\"t3ver_stage\":0,\"tstamp\":1771589810,\"uid\":6}',0,'0400$3db361709ad240b1881e14227d68a952:768f9cd4e98812f969df7ebe17f11b50'),
(130,1771589810,1,'BE',1,0,35,'tx_themecamino_list_item','{\"sorting_foreign\":10,\"hidden\":0,\"l10n_parent\":\"33\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/mastodontech.de\\\\\\/@kanti\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"Mastodon\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"17\\\"}\",\"pid\":3,\"sys_language_uid\":1,\"l10n_source\":33,\"l10n_state\":null,\"uid_foreign\":\"17\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/mastodontech.de\\/@kanti\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Mastodon\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589810,\"t3ver_stage\":0,\"tstamp\":1771589810,\"uid\":35}',0,'0400$307cc8aeb4aaf72f4875db4b8f85c01a:8692c0a19f954e2d7b26a3044d69a766'),
(131,1771589810,1,'BE',1,0,36,'tx_themecamino_list_item','{\"sorting_foreign\":514,\"hidden\":0,\"l10n_parent\":\"34\",\"l10n_diffsource\":\"{\\\"category\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"fieldname\\\":\\\"tx_themecamino_list_elements\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"images\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"link\\\":\\\"https:\\\\\\/\\\\\\/typo3.slack.com\\\\\\/team\\\\\\/U046M1E1J\\\",\\\"link_config\\\":\\\"\\\",\\\"link_icon\\\":\\\"\\\",\\\"link_label\\\":\\\"TYPO3 Slack\\\",\\\"sorting_foreign\\\":\\\"514\\\",\\\"tablename\\\":\\\"tt_content\\\",\\\"text\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"17\\\"}\",\"pid\":3,\"sys_language_uid\":1,\"l10n_source\":34,\"l10n_state\":null,\"uid_foreign\":\"17\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/typo3.slack.com\\/team\\/U046M1E1J\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"TYPO3 Slack\",\"text\":null,\"tablename\":\"tt_content\",\"fieldname\":\"tx_themecamino_list_elements\",\"crdate\":1771589810,\"t3ver_stage\":0,\"tstamp\":1771589810,\"uid\":36}',0,'0400$ebde0d4d28bbba9b2b14a881bc8e6068:59102438fd964f055097b008a641deef'),
(132,1771589810,1,'BE',1,0,22,'tt_content','{\"CType\":\"camino_author\",\"colPos\":\"1\",\"l18n_parent\":\"17\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"pid\":3,\"sorting\":512,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":17,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_author\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"Maintainer of:\\\\r\\\\n- EXT:visual_editor\\\\r\\\\n- EXT:storybook\\\\r\\\\n- webdevops\\\\\\/php\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"1\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Matthias Vogel\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"1\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"Technical Leader\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"2\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"frame_class\":\"default\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"Matthias Vogel\",\"header_layout\":\"0\",\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"Technical Leader\",\"bodytext\":\"Maintainer of:\\r\\n- EXT:visual_editor\\r\\n- EXT:storybook\\r\\n- webdevops\\/php\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_header_style\":\"0\",\"crdate\":1771589810,\"t3ver_stage\":0,\"tstamp\":1771589810,\"uid\":22}',0,'0400$20e5fcece6a72f831a4d49e0924e6c90:1a929832156241f61c37ce68bcae4a3c'),
(133,1771589813,2,'BE',1,0,20,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$a849331abb8064c68fc91b4a80ea922b:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(134,1771589815,2,'BE',1,0,21,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$76fe009850c7f8c334c64a41f34b6f86:7fd72e21409e45562c51e7581fc2cb0d'),
(135,1771589817,2,'BE',1,0,22,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$50318397063c02d111f3cf43a2ac11b9:1a929832156241f61c37ce68bcae4a3c'),
(136,1771589834,2,'BE',1,0,22,'tt_content','{\"oldRecord\":{\"bodytext\":\"Maintainer of:\\r\\n- EXT:visual_editor\\r\\n- EXT:storybook\\r\\n- webdevops\\/php\"},\"newRecord\":{\"bodytext\":\"Maintainer von:\\n- EXT:visual_editor\\n- EXT:storybook\\n- webdevops\\/php\"}}',0,'0400$ce50f5e1cc7d9d96c492a2503a8fcd1f:1a929832156241f61c37ce68bcae4a3c'),
(137,1771589845,2,'BE',1,0,19,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>We\\u2019re <strong>anders und sehr<\\/strong>, a Stuttgart-based 360\\u00b0 digital agency bringing together <strong>concept &amp; design<\\/strong>, <strong>branding &amp; marketing<\\/strong>, and <strong>development &amp; technology<\\/strong> under one roof.<\\/p>\\r\\n<p>Thinking differently is part of our DNA. We shift perspectives, question assumptions, and explore unconventional routes with curiosity\\u2014while staying grounded, so we don\\u2019t have to gamble later when it\\u2019s time to ship.<\\/p>\\r\\n<p>We call ourselves <strong>digital architects<\\/strong> for a reason: great digital work needs a beautiful fa\\u00e7ade <i>and<\\/i> a stable foundation. That\\u2019s why we start with strategy and concept, then design, build, and deliver a solution that works as a coherent whole. We build everything\\u2014just not castles in the air.<\\/p>\\r\\n<p>What makes us different? <strong>Ideas.<\\/strong> Even a small one can have a big impact when it\\u2019s unique and hits the nerve of your audience. We see ourselves as explorers and pioneers\\u2014turning ideas into business value without chasing every trend.<\\/p>\\r\\n<p>Behind it all is a team that\\u2019s diverse, a little wild in the best way, and fiercely loyal to clients, craft, and each other. After 25 years and 28+ minds, we\\u2019re still hungry for the next perspective.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"bodytext\":\"<p>We are <strong>anders und sehr<\\/strong>, an award-winning 360 degree digital agency based in Stuttgart. We bring <strong>creation<\\/strong>, <strong>marketing<\\/strong>, and <strong>digital platforms<\\/strong> together in one team, so strategy, design, and technology work as a coherent whole from day one.<\\/p>\\r\\n<p>As <strong>digital architects<\\/strong>, we believe great digital work needs more than a beautiful facade. It needs a foundation that lasts. That is why we start with concept and planning, challenge assumptions early, and then craft the finished solution with the same love for detail. We build everything, but no castles in the air.<\\/p>\\r\\n<p>What makes us different is <strong>ideas<\\/strong>. Even the smallest idea can create real impact when it is unique and speaks directly to the people you want to reach. We see ourselves as explorers and pioneers, opening new horizons and turning vision into reality.<\\/p>\",\"l18n_diffsource\":\"{\\\"bodytext\\\":\\\"\\\"}\"}}',0,'0400$29d861265d7750fd96c7f894fd86c962:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(138,1771589885,2,'BE',1,0,21,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>We\\u2019re <strong>anders und sehr<\\/strong>, a Stuttgart-based 360\\u00b0 digital agency bringing together <strong>concept &amp; design<\\/strong>, <strong>branding &amp; marketing<\\/strong>, and <strong>development &amp; technology<\\/strong> under one roof.<\\/p>\\r\\n<p>Thinking differently is part of our DNA. We shift perspectives, question assumptions, and explore unconventional routes with curiosity\\u2014while staying grounded, so we don\\u2019t have to gamble later when it\\u2019s time to ship.<\\/p>\\r\\n<p>We call ourselves <strong>digital architects<\\/strong> for a reason: great digital work needs a beautiful fa\\u00e7ade <i>and<\\/i> a stable foundation. That\\u2019s why we start with strategy and concept, then design, build, and deliver a solution that works as a coherent whole. We build everything\\u2014just not castles in the air.<\\/p>\\r\\n<p>What makes us different? <strong>Ideas.<\\/strong> Even a small one can have a big impact when it\\u2019s unique and hits the nerve of your audience. We see ourselves as explorers and pioneers\\u2014turning ideas into business value without chasing every trend.<\\/p>\\r\\n<p>Behind it all is a team that\\u2019s diverse, a little wild in the best way, and fiercely loyal to clients, craft, and each other. After 25 years and 28+ minds, we\\u2019re still hungry for the next perspective.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"text\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"<p>We\\\\u2019re <strong>anders und sehr<\\\\\\/strong>, a Stuttgart-based 360\\\\u00b0 digital agency bringing together <strong>concept &amp; design<\\\\\\/strong>, <strong>branding &amp; marketing<\\\\\\/strong>, and <strong>development &amp; technology<\\\\\\/strong> under one roof.<\\\\\\/p>\\\\r\\\\n<p>Thinking differently is part of our DNA. We shift perspectives, question assumptions, and explore unconventional routes with curiosity\\\\u2014while staying grounded, so we don\\\\u2019t have to gamble later when it\\\\u2019s time to ship.<\\\\\\/p>\\\\r\\\\n<p>We call ourselves <strong>digital architects<\\\\\\/strong> for a reason: great digital work needs a beautiful fa\\\\u00e7ade <i>and<\\\\\\/i> a stable foundation. That\\\\u2019s why we start with strategy and concept, then design, build, and deliver a solution that works as a coherent whole. We build everything\\\\u2014just not castles in the air.<\\\\\\/p>\\\\r\\\\n<p>What makes us different? <strong>Ideas.<\\\\\\/strong> Even a small one can have a big impact when it\\\\u2019s unique and hits the nerve of your audience. We see ourselves as explorers and pioneers\\\\u2014turning ideas into business value without chasing every trend.<\\\\\\/p>\\\\r\\\\n<p>Behind it all is a team that\\\\u2019s diverse, a little wild in the best way, and fiercely loyal to clients, craft, and each other. After 25 years and 28+ minds, we\\\\u2019re still hungry for the next perspective.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"0\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\"},\"newRecord\":{\"bodytext\":\"<p>Wir sind <strong>anders und sehr<\\/strong>, eine preisgekr\\u00f6nte 360-Grad-Digitalagentur mit Sitz in Stuttgart. Wir vereinen <strong>Kreation<\\/strong>, <strong>Marketing <\\/strong>und <strong>digitale Plattformen <\\/strong>in einem Team, sodass Strategie, Design und Technologie vom ersten Tag an als stimmiges Ganzes funktionieren.<\\/p>\\r\\n<p>Als <strong>digitale Architekten <\\/strong>glauben wir, dass gro\\u00dfartige digitale Arbeit mehr als nur eine sch\\u00f6ne Fassade braucht. Sie braucht ein Fundament, das Bestand hat. Deshalb beginnen wir mit Konzept und Planung, hinterfragen fr\\u00fchzeitig Annahmen und entwickeln dann mit der gleichen Liebe zum Detail die fertige L\\u00f6sung. Wir bauen alles, aber keine Luftschl\\u00f6sser.<\\/p>\\r\\n<p>Was uns auszeichnet, sind <strong>Ideen<\\/strong>. Selbst die kleinste Idee kann eine echte Wirkung erzielen, wenn sie einzigartig ist und die Menschen, die Sie erreichen wollen, direkt anspricht. Wir verstehen uns als Entdecker und Pioniere, die neue Horizonte er\\u00f6ffnen und Visionen Wirklichkeit werden lassen.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"text\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"<p>We are <strong>anders und sehr<\\\\\\/strong>, an award-winning 360 degree digital agency based in Stuttgart. We bring <strong>creation<\\\\\\/strong>, <strong>marketing<\\\\\\/strong>, and <strong>digital platforms<\\\\\\/strong> together in one team, so strategy, design, and technology work as a coherent whole from day one.<\\\\\\/p>\\\\r\\\\n<p>As <strong>digital architects<\\\\\\/strong>, we believe great digital work needs more than a beautiful facade. It needs a foundation that lasts. That is why we start with concept and planning, challenge assumptions early, and then craft the finished solution with the same love for detail. We build everything, but no castles in the air.<\\\\\\/p>\\\\r\\\\n<p>What makes us different is <strong>ideas<\\\\\\/strong>. Even the smallest idea can create real impact when it is unique and speaks directly to the people you want to reach. We see ourselves as explorers and pioneers, opening new horizons and turning vision into reality.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"0\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\"}}',0,'0400$0fbb32900d633b9ae2beaae35e5a7b83:7fd72e21409e45562c51e7581fc2cb0d'),
(139,1771589913,2,'BE',1,0,20,'tt_content','{\"oldRecord\":{\"header\":\"\"},\"newRecord\":{\"header\":\"We build digital that feels effortless.\"}}',0,'0400$d17ba4ad98d9c08ddedb33da016bd2b9:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(140,1771589962,2,'BE',1,0,20,'tt_content','{\"oldRecord\":{\"header\":\"We build digital that feels effortless.\",\"subheader\":\"\"},\"newRecord\":{\"header\":\"Effortless Digital.\",\"subheader\":\"We build experiences that feel simple for users and stay solid behind the scenes.\"}}',0,'0400$bb03ffdbd4f6b098a80e30af192472b2:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(141,1771590212,2,'BE',1,0,18,'tt_content','{\"oldRecord\":{\"subheader\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"subheader\":\"We build experiences that feel simple for users and stay solid behind the scenes.\",\"l18n_diffsource\":\"{\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$3bdcd1534ac5e902283ecf623c7c03b3:0a64be1ae1f9096cc345beb76e5e2095'),
(142,1771590217,2,'BE',1,0,18,'tt_content','{\"oldRecord\":{\"header\":\"\",\"l18n_diffsource\":\"{\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Effortless Digital.\",\"l18n_diffsource\":\"{\\\"header\\\":\\\"\\\"}\"}}',0,'0400$11be64f47773f67067311534c5c7de4a:0a64be1ae1f9096cc345beb76e5e2095'),
(143,1771590266,2,'BE',1,0,20,'tt_content','{\"oldRecord\":{\"header\":\"Effortless Digital.\",\"subheader\":\"We build experiences that feel simple for users and stay solid behind the scenes.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_hero_small\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"2\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"1\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"0\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\"},\"newRecord\":{\"header\":\"Digitale Leichtigkeit.\",\"subheader\":\"Wir schaffen Erlebnisse, die f\\u00fcr die Nutzer einfach sind und hinter den Kulissen reibungslos funktionieren.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"camino_hero_small\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"2\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Effortless Digital.\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"1\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"We build experiences that feel simple for users and stay solid behind the scenes.\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_themecamino_header_style\\\":\\\"0\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"0\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\"}}',0,'0400$98e25d617b1efe038ad71437a0cdd35f:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(144,1771590311,2,'BE',1,0,20,'tt_content','{\"oldRecord\":{\"subheader\":\"Wir schaffen Erlebnisse, die f\\u00fcr die Nutzer einfach sind und hinter den Kulissen reibungslos funktionieren.\"},\"newRecord\":{\"subheader\":\"Wir schaffen einfache Nutzererlebnisse, die im Hintergrund reibungslos laufen.\"}}',0,'0400$c5edb6a9fe760de3d8fbd4ddd7916f25:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(145,1771590643,1,'BE',2,0,3,'be_users','{\"admin\":1,\"lang\":\"default\",\"options\":3,\"disable\":0,\"lastlogin\":0,\"starttime\":0,\"endtime\":0,\"pid\":0,\"username\":\"admin2\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$OW8xOW40aHVCLjRZYlVaaA$Cuy\\/6Put0B8bBL1vugXVDoFXdjCpaJCZLwO3Zb6tt4g\",\"email\":\"\",\"usergroup\":\"\",\"crdate\":1771590643,\"tstamp\":1771590643,\"uid\":3}',0,'0400$39c5abd2b0d75199ea07aa0e5f7b1584:0c759eb140de7eba987dfc32521df385'),
(146,1771590770,1,'BE',2,0,4,'be_users','{\"admin\":0,\"lang\":\"default\",\"workspace_perms\":1,\"options\":3,\"file_permissions\":\"readFolder,writeFolder,addFolder,renameFolder,moveFolder,deleteFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile\",\"disable\":0,\"lastlogin\":0,\"starttime\":0,\"endtime\":0,\"pid\":0,\"username\":\"admin2\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$Nks3UkFRL1pGYWlNeWJlbg$Jd\\/U9jYa7NCNXK24ubcmcV0PPoJMrhGjRSpg6B59sl4\",\"email\":\"\",\"usergroup\":\"\",\"crdate\":1771590770,\"tstamp\":1771590770,\"uid\":4}',0,'0400$d14365d41a71d408e1d4a8e6328755f7:aac4b550575ba72e5642bbb582eeb2cf'),
(147,1771590878,1,'BE',2,0,5,'be_users','{\"admin\":1,\"lang\":\"default\",\"options\":3,\"disable\":0,\"lastlogin\":0,\"starttime\":0,\"endtime\":0,\"pid\":0,\"username\":\"admin\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$c3FiUkRFaWV1bVkuMkM1Qg$y8LaSZosqeSWPjedrGESKi9XNPg9WsQFcajb1v2rAz8\",\"email\":\"\",\"usergroup\":\"\",\"crdate\":1771590878,\"tstamp\":1771590878,\"uid\":5}',0,'0400$f67f25e17ddddd67753a56d6ca3f2f23:a0b58bd056a0ca6eaa608c4ab57e86c0'),
(148,1771590982,1,'BE',2,0,6,'be_users','{\"admin\":1,\"lang\":\"en\",\"options\":3,\"disable\":0,\"lastlogin\":0,\"starttime\":0,\"endtime\":0,\"pid\":0,\"username\":\"demo\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$b0lLejhyS1FhQjVGM3pycg$cB5E7eJq5XerNoP\\/x2u3PlyOGFp7m9s7HpmJjiXF8z8\",\"email\":\"\",\"usergroup\":\"\",\"crdate\":1771590982,\"tstamp\":1771590982,\"uid\":6}',0,'0400$2da5afae0a7f9c2416a1b84ed87fa9cf:2196eadf702de069f4b28b6c91a43894');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1771582482,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1771585476,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.20.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(3,1771585483,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.20.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(4,1771585490,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.20.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(5,1771585501,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.20.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(6,1771585515,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.20.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(7,1771585706,1,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','172.20.0.5','[\"admin\"]',-1,0,'',0,'','info',NULL,NULL),
(8,1771585730,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"password2\" in /var/www/html/vendor/typo3/cms-setup/Classes/Controller/SetupModuleController.php line 333',5,'php','172.20.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(9,1771585730,1,1,0,'',0,0,'Personal settings changed',254,'default','172.20.0.5','',-1,0,'',0,'','info',NULL,NULL),
(10,1771585739,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"password2\" in /var/www/html/vendor/typo3/cms-setup/Classes/Controller/SetupModuleController.php line 333',5,'php','172.20.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(11,1771585739,1,1,0,'',0,0,'Personal settings changed',254,'default','172.20.0.5','',-1,0,'',0,'','info',NULL,NULL),
(12,1771585887,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1770212183: The \"contentArea\" argument must be an instance of TYPO3\\CMS\\Core\\Page\\ContentArea | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/Render/ContentAreaViewHelper.php in line 76. Requested URL: https://ddev-demo-setup-visual-editor.ddev.site:33001/?editMode=1&cHash=3780a2221f042a54e0c68a0db7e06299ced2f7739be4cd78580bbcd4f756c9aa',5,'php','172.20.0.5','',-1,0,'',0,'','error',NULL,NULL),
(13,1771585905,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"1\"}',0,0,'',0,'','info',NULL,NULL),
(14,1771585966,1,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"2\"}',1,0,'',0,'','info',NULL,NULL),
(15,1771585980,1,1,0,'site',0,0,'Site settings changed for \'%s\': %s',6,'site','172.20.0.5','[\"main\",\"{\\\"settings\\\":{\\\"camino.colorScheme\\\":\\\"theme-ocean-breeze\\\"},\\\"changes\\\":[\\\"camino.colorScheme\\\"],\\\"deletions\\\":[]}\"]',-1,0,'',0,'','info',NULL,NULL),
(16,1771585992,1,1,0,'site',0,0,'Site settings changed for \'%s\': %s',6,'site','172.20.0.5','[\"main\",\"{\\\"settings\\\":{\\\"camino.colorScheme\\\":\\\"theme-violet-velvet\\\"},\\\"changes\\\":[\\\"camino.colorScheme\\\"],\\\"deletions\\\":[]}\"]',-1,0,'',0,'','info',NULL,NULL),
(17,1771588457,1,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(18,1771588472,1,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"4\"}',1,0,'',0,'','info',NULL,NULL),
(19,1771588480,1,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"5\"}',1,0,'',0,'','info',NULL,NULL),
(20,1771588501,1,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"6\"}',1,0,'',0,'','info',NULL,NULL),
(21,1771588524,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file','172.20.0.5','{\"identifier\":\"PinkCat.png\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(22,1771588536,1,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(23,1771588536,1,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":2,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(24,1771588552,1,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"8\"}',1,0,'',0,'','info',NULL,NULL),
(25,1771588619,1,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(26,1771588620,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"10\"}',1,0,'',0,'','info',NULL,NULL),
(27,1771588625,1,4,3,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(28,1771588625,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"12\"}',1,0,'',0,'','info',NULL,NULL),
(29,1771588651,1,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(30,1771588651,1,1,1,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(31,1771588651,1,1,2,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(32,1771588651,1,1,3,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(33,1771588651,1,1,4,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(34,1771588651,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(35,1771588687,1,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(36,1771588687,1,1,5,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(37,1771588687,1,1,6,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(38,1771588687,1,1,7,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(39,1771588687,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(40,1771588702,1,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(41,1771588702,1,1,8,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":8,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(42,1771588702,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(43,1771588715,1,2,8,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":8,\"history\":\"24\"}',1,0,'',0,'','info',NULL,NULL),
(44,1771588715,1,1,9,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":9,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(45,1771588715,1,1,10,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":10,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(46,1771588715,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(47,1771588721,1,2,9,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":9,\"history\":\"27\"}',1,0,'',0,'','info',NULL,NULL),
(48,1771588721,1,2,10,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":10,\"history\":\"28\"}',1,0,'',0,'','info',NULL,NULL),
(49,1771588749,1,1,7,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(50,1771588749,1,1,11,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(51,1771588749,1,1,12,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(52,1771588749,1,1,13,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":13,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(53,1771588749,1,1,14,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":14,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(54,1771588749,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(55,1771588750,1,2,11,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":11,\"history\":\"34\"}',1,0,'',0,'','info',NULL,NULL),
(56,1771588750,1,2,12,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":12,\"history\":\"35\"}',1,0,'',0,'','info',NULL,NULL),
(57,1771588750,1,2,13,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":13,\"history\":\"36\"}',1,0,'',0,'','info',NULL,NULL),
(58,1771588750,1,2,14,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":14,\"history\":\"37\"}',1,0,'',0,'','info',NULL,NULL),
(59,1771588772,1,1,8,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":8,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(60,1771588772,1,1,15,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":15,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(61,1771588772,1,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":8,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(62,1771588790,1,2,15,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":15,\"history\":\"40\"}',1,0,'',0,'','info',NULL,NULL),
(63,1771588790,1,1,16,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":16,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(64,1771588790,1,1,17,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":17,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(65,1771588790,1,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":8,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(66,1771588821,1,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":8,\"history\":\"43\"}',1,0,'',0,'','info',NULL,NULL),
(67,1771588821,1,2,15,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":15,\"history\":\"44\"}',1,0,'',0,'','info',NULL,NULL),
(68,1771588821,1,2,17,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":17,\"history\":\"45\"}',1,0,'',0,'','info',NULL,NULL),
(69,1771588821,1,3,16,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":16,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(70,1771588848,1,2,11,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":11,\"history\":\"47\"}',1,0,'',0,'','info',NULL,NULL),
(71,1771588861,1,2,5,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":5,\"history\":\"48\"}',1,0,'',0,'','info',NULL,NULL),
(72,1771588861,1,2,7,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":7,\"history\":\"49\"}',1,0,'',0,'','info',NULL,NULL),
(73,1771588861,1,2,6,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":6,\"history\":\"50\"}',1,0,'',0,'','info',NULL,NULL),
(74,1771588888,1,2,14,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":14,\"history\":\"51\"}',1,0,'',0,'','info',NULL,NULL),
(75,1771588892,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"52\"}',1,0,'',0,'','info',NULL,NULL),
(76,1771588892,1,2,11,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":11,\"history\":\"53\"}',1,0,'',0,'','info',NULL,NULL),
(77,1771588892,1,3,12,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(78,1771588906,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"55\"}',1,0,'',0,'','info',NULL,NULL),
(79,1771588906,1,3,6,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(80,1771588965,1,2,8,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":8,\"history\":\"57\"}',1,0,'',0,'','info',NULL,NULL),
(81,1771588965,1,1,18,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":18,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(82,1771588965,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(83,1771588965,1,3,10,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":10,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(84,1771588965,1,3,9,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":9,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(85,1771588977,1,1,19,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":19,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(86,1771588977,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(87,1771588993,1,2,18,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_themecamino_list_item\",\"uid\":18,\"history\":\"62\"}',1,0,'',0,'','info',NULL,NULL),
(88,1771589000,1,2,11,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":11,\"history\":\"63\"}',1,0,'',0,'','info',NULL,NULL),
(89,1771589000,1,2,13,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":13,\"history\":\"64\"}',1,0,'',0,'','info',NULL,NULL),
(90,1771589000,1,2,14,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":14,\"history\":\"65\"}',1,0,'',0,'','info',NULL,NULL),
(91,1771589006,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"66\"}',1,0,'',0,'','info',NULL,NULL),
(92,1771589006,1,2,13,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":13,\"history\":\"67\"}',1,0,'',0,'','info',NULL,NULL),
(93,1771589006,1,3,11,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(94,1771589012,1,2,8,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":8,\"history\":\"69\"}',1,0,'',0,'','info',NULL,NULL),
(95,1771589012,1,2,18,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":18,\"history\":\"70\"}',1,0,'',0,'','info',NULL,NULL),
(96,1771589034,1,2,8,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":8,\"history\":\"71\"}',1,0,'',0,'','info',NULL,NULL),
(97,1771589045,1,2,19,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":19,\"history\":\"72\"}',1,0,'',0,'','info',NULL,NULL),
(98,1771589074,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.20.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(99,1771589075,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.20.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(100,1771589092,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":2,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(101,1771589092,1,1,2,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"sys_file_reference\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(102,1771589092,1,1,9,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":9,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(103,1771589092,1,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":9,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(104,1771589092,1,1,10,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":10,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(105,1771589092,1,1,11,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(106,1771589092,1,1,20,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":20,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(107,1771589092,1,1,21,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":21,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(108,1771589092,1,1,22,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":22,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(109,1771589092,1,1,23,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":23,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(110,1771589092,1,1,12,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(111,1771589092,1,2,12,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":12,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(112,1771589092,1,1,24,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":24,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(113,1771589092,1,1,25,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":25,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(114,1771589092,1,1,26,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":26,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(115,1771589092,1,1,13,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":13,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(116,1771589092,1,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(117,1771589092,1,1,27,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":27,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(118,1771589092,1,1,28,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":28,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(119,1771589092,1,1,14,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":14,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(120,1771589092,1,2,14,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":14,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(121,1771589092,1,1,29,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":29,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(122,1771589092,1,1,30,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":30,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(123,1771589092,1,1,15,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":15,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(124,1771589092,1,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(125,1771589092,1,1,31,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":31,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(126,1771589092,1,1,32,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":32,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(127,1771589092,1,1,16,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":16,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(128,1771589092,1,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(129,1771589096,1,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":9,\"history\":\"96\"}',1,0,'',0,'','info',NULL,NULL),
(130,1771589097,1,2,10,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":10,\"history\":\"97\"}',1,0,'',0,'','info',NULL,NULL),
(131,1771589098,1,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":\"98\"}',1,0,'',0,'','info',NULL,NULL),
(132,1771589099,1,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":\"99\"}',1,0,'',0,'','info',NULL,NULL),
(133,1771589100,1,2,14,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":14,\"history\":\"100\"}',1,0,'',0,'','info',NULL,NULL),
(134,1771589101,1,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":\"101\"}',1,0,'',0,'','info',NULL,NULL),
(135,1771589101,1,2,12,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":12,\"history\":\"102\"}',1,0,'',0,'','info',NULL,NULL),
(136,1771589103,1,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":\"103\"}',1,0,'',0,'','info',NULL,NULL),
(137,1771589159,1,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":9,\"history\":\"104\"}',1,0,'',0,'','info',NULL,NULL),
(138,1771589169,1,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":9,\"history\":\"105\"}',1,0,'',0,'','info',NULL,NULL),
(139,1771589179,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"106\"}',1,0,'',0,'','info',NULL,NULL),
(140,1771589265,1,2,10,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":10,\"history\":\"107\"}',1,0,'',0,'','info',NULL,NULL),
(141,1771589302,1,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":11,\"history\":\"108\"}',1,0,'',0,'','info',NULL,NULL),
(142,1771589318,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"109\"}',0,0,'',0,'','info',NULL,NULL),
(143,1771589325,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"110\"}',0,0,'',0,'','info',NULL,NULL),
(144,1771589325,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"111\"}',0,0,'',0,'','info',NULL,NULL),
(145,1771589332,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(146,1771589343,1,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(147,1771589348,1,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"114\"}',1,0,'',0,'','info',NULL,NULL),
(148,1771589351,1,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":4,\"history\":\"115\"}',1,0,'',0,'','info',NULL,NULL),
(149,1771589430,1,1,0,'',0,1,'No file was uploaded',2,'file','172.20.0.5','',-1,0,'',0,'','info',NULL,NULL),
(150,1771589440,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file','172.20.0.5','{\"identifier\":\"pp.jpeg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(151,1771589455,1,1,17,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":17,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(152,1771589455,1,1,3,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"sys_file_reference\",\"uid\":3,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(153,1771589455,1,1,33,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":33,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(154,1771589455,1,1,34,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":34,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(155,1771589455,1,2,17,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":17,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(156,1771589455,1,2,17,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":17,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(157,1771589494,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file','172.20.0.5','{\"identifier\":\"Cat.png\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(158,1771589511,1,1,18,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":18,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(159,1771589511,1,1,4,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"sys_file_reference\",\"uid\":4,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(160,1771589511,1,2,18,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":18,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(161,1771589727,1,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"122\"}',1,0,'',0,'','info',NULL,NULL),
(162,1771589733,1,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"123\"}',1,0,'',0,'','info',NULL,NULL),
(163,1771589738,1,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"124\"}',1,0,'',0,'','info',NULL,NULL),
(164,1771589750,1,1,19,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":19,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(165,1771589810,1,1,5,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(166,1771589810,1,1,20,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":20,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(167,1771589810,1,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":20,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(168,1771589810,1,1,21,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":21,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(169,1771589810,1,1,6,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"sys_file_reference\",\"uid\":6,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(170,1771589810,1,1,35,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":35,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(171,1771589810,1,1,36,'tx_themecamino_list_item',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tx_themecamino_list_item\",\"uid\":36,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(172,1771589810,1,1,22,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":22,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(173,1771589810,1,2,22,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":22,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(174,1771589810,1,2,22,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":22,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(175,1771589813,1,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":20,\"history\":\"133\"}',3,0,'',0,'','info',NULL,NULL),
(176,1771589815,1,2,21,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":21,\"history\":\"134\"}',3,0,'',0,'','info',NULL,NULL),
(177,1771589817,1,2,22,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.20.0.5','{\"table\":\"tt_content\",\"uid\":22,\"history\":\"135\"}',3,0,'',0,'','info',NULL,NULL),
(178,1771589834,1,2,22,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":22,\"history\":\"136\"}',3,0,'',0,'','info',NULL,NULL),
(179,1771589845,1,2,19,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":19,\"history\":\"137\"}',3,0,'',0,'','info',NULL,NULL),
(180,1771589885,1,2,21,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":21,\"history\":\"138\"}',3,0,'',0,'','info',NULL,NULL),
(181,1771589913,1,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"history\":\"139\"}',3,0,'',0,'','info',NULL,NULL),
(182,1771589962,1,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"history\":\"140\"}',3,0,'',0,'','info',NULL,NULL),
(183,1771590212,1,2,18,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":18,\"history\":\"141\"}',3,0,'',0,'','info',NULL,NULL),
(184,1771590217,1,2,18,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":18,\"history\":\"142\"}',3,0,'',0,'','info',NULL,NULL),
(185,1771590266,1,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"history\":\"143\"}',3,0,'',0,'','info',NULL,NULL),
(186,1771590311,1,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"history\":\"144\"}',3,0,'',0,'','info',NULL,NULL),
(187,1771590591,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user','172.20.0.5','[\"admin\"]',-1,0,'',0,'','info',NULL,NULL),
(188,1771590595,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(189,1771590643,2,1,3,'be_users',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"be_users\",\"uid\":3,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(190,1771590670,3,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin2\"]',-1,-99,'',0,'','info',NULL,NULL),
(191,1771590770,2,1,4,'be_users',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"be_users\",\"uid\":4,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(192,1771590878,2,1,5,'be_users',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"be_users\",\"uid\":5,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(193,1771590982,2,1,6,'be_users',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"be_users\",\"uid\":6,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(194,1771591163,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(195,1771591168,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('05f831cd80407934e5cb2224bbc462e9','tt_content',8,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',15,'',0,0,2147483647,0,0,''),
('08dc722e2a75b9b063eb21e68e045a1b','tx_themecamino_list_item',20,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',1,'',0,0,2147483647,0,0,''),
('0920f0ae1b831964333f41f4a8958f56','tx_themecamino_list_item',22,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',3,'',0,0,2147483647,0,0,''),
('092af57dcfb4192a924210dbf0244e2e','tx_themecamino_list_item',36,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',34,'',0,0,2147483647,0,0,''),
('09c5c9693371f5a4fb5597ec48e251e5','tt_content',13,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',2,0,'tx_themecamino_list_item',26,'',0,0,2147483647,0,0,''),
('0f1f91a7ffc5a99cb607fd379b7149fe','tt_content',16,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',8,'',0,0,2147483647,0,0,''),
('0fdc0a6b3fc8795989272ce8be497c82','tt_content',20,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',5,'',0,0,2147483647,0,0,''),
('130c87e0756c9c88dd87d1f0a6b4c5ae','tx_themecamino_list_item',21,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',12,'',0,0,2147483647,0,0,''),
('1473e1693f57256158127ba7d8e34672','tx_themecamino_list_item',31,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',16,'',0,0,2147483647,0,0,''),
('156995d0182e1edd45f46109caeb2e39','tt_content',4,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',2,0,'tx_themecamino_list_item',3,'',0,0,2147483647,0,0,''),
('1952b83c31d89ec8365738f5a13f8888','tx_themecamino_list_item',33,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',17,'',0,0,2147483647,0,0,''),
('1aac124ea9d31b58b2ea278defee4d93','tt_content',17,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('1b3416c1ef833488ddcec6d6667a2f5b','tx_themecamino_list_item',25,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',13,'',0,0,2147483647,0,0,''),
('1c8d666e31ba5651e4afe1c86f2603a0','sys_file_reference',6,'l10n_parent',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('1d5c1426c4d8cec987f5286baa11b477','tt_content',17,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',34,'',0,0,2147483647,0,0,''),
('207e03ce084e3d612bd7b9eb8ef0da6c','tt_content',22,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',35,'',0,0,2147483647,0,0,''),
('22bb7e339e3c05c6bd930ca2de61459c','tt_content',4,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',1,'',0,0,2147483647,0,0,''),
('22ccb843f0b23b0dafc8ab7264e86a0c','tx_themecamino_list_item',29,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',15,'',0,0,2147483647,0,0,''),
('245300f5f47ec6751c2c74d4dc1e07fd','tx_themecamino_list_item',20,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',12,'',0,0,2147483647,0,0,''),
('2831e1ab561f03531d2200d41e6ebfc9','tt_content',12,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',20,'',0,0,2147483647,0,0,''),
('2c992c6dfbc65cad80c2ad14527bcf7a','tt_content',10,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',3,'',0,0,2147483647,0,0,''),
('363a9e113503620ecef9238f87707287','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('3e2e684318147bbf940eca156feca31f','tt_content',14,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',27,'',0,0,2147483647,0,0,''),
('3f697f8808b12d8858da4cdcd8e2de02','tx_themecamino_list_item',30,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',15,'',0,0,2147483647,0,0,''),
('404bd9855976315587b8addc85bbf7f9','tx_themecamino_list_item',36,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',22,'',0,0,2147483647,0,0,''),
('42271dbc694c12b7ca89e9469c5aab24','tt_content',15,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',30,'',0,0,2147483647,0,0,''),
('43632f79d45f225e3b9a0e565915badb','tx_themecamino_list_item',24,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',13,'',0,0,2147483647,0,0,''),
('470e2d3b5bcfb822e442a8d8b0403deb','tx_themecamino_list_item',14,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('47e7c704391d995d9b17e1a6af0759c3','tt_content',15,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',29,'',0,0,2147483647,0,0,''),
('4b8c8f5ec73cd5784f6ef17323ab81b4','tx_themecamino_list_item',31,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',15,'',0,0,2147483647,0,0,''),
('523a0875768bc32af9df38d680141e8f','tx_themecamino_list_item',22,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',12,'',0,0,2147483647,0,0,''),
('52c82ee8732847d32b0005a41e70eb69','tx_themecamino_list_item',29,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',14,'',0,0,2147483647,0,0,''),
('55c31936a5832751de45542f11ed0f83','tx_themecamino_list_item',25,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',7,'',0,0,2147483647,0,0,''),
('57dbaede9ce86c6451a48b42e7214c53','tt_content',6,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',8,'',0,0,2147483647,0,0,''),
('5a61f8de64985790721117439cd27f2e','tt_content',15,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('6246de89a84d5689e9af7b1e25d5f176','pages',4,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('64400b2f8b24c4dd433ca41de592668a','tx_themecamino_list_item',30,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',13,'',0,0,2147483647,0,0,''),
('6468c6d2ab23066fdef798e45b72ec0b','tx_themecamino_list_item',26,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',13,'',0,0,2147483647,0,0,''),
('65666fd754e6afc01c90f264e2d398bd','tx_themecamino_list_item',8,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',6,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('666dcc715b04861f2eab107f856c1fc6','tt_content',6,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',18,'',0,0,2147483647,0,0,''),
('670bb3bfaea7468551fcf074664bd77a','tt_content',11,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',1,'',0,0,2147483647,0,0,''),
('67ccc64ad217639586450f6677caca8c','tx_themecamino_list_item',34,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',17,'',0,0,2147483647,0,0,''),
('68275e712ee6626930e72c076be4577e','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('6896ddefe3df586199b6a52511253ea8','tx_themecamino_list_item',7,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',5,'',0,0,2147483647,0,0,''),
('6984abfd3913207b29ddf516090069ea','tt_content',12,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',4,'',0,0,2147483647,0,0,''),
('7172efb2aabf9df5c2577b4d512b7bc7','tx_themecamino_list_item',35,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',33,'',0,0,2147483647,0,0,''),
('719d0531ac14091b8f46e2026802ee46','tx_themecamino_list_item',19,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',5,'',0,0,2147483647,0,0,''),
('72c032a31f829aedd27007d800da8f9b','tt_content',9,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('756c951bfb8576b54188c5b6f948eb28','tt_content',22,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',36,'',0,0,2147483647,0,0,''),
('7640956a15ab703707f62b2810e50a5c','tt_content',14,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',6,'',0,0,2147483647,0,0,''),
('76e18aca8848d16527ff50b0f0020d3a','tx_themecamino_list_item',18,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',6,'',0,0,2147483647,0,0,''),
('77876c0cba6cc80b98843569be5c85ad','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('7e430b1a535598e7e8961d03005b79ce','sys_file_reference',2,'l10n_parent',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('80fea6c2bb568924e799cc7fda5ebc3f','tx_themecamino_list_item',23,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',4,'',0,0,2147483647,0,0,''),
('897c4689ccf3eb9be798f8fd73abae81','tt_content',22,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('89d150ad1cb8b6a3cf125a22cea67b7a','tt_content',13,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',5,'',0,0,2147483647,0,0,''),
('8d95c86e712a1987d23343fb045e115c','tt_content',14,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',28,'',0,0,2147483647,0,0,''),
('8e12de77677803d8bdfd11ec115db16d','tx_themecamino_list_item',21,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',2,'',0,0,2147483647,0,0,''),
('8ed32a35c75038d5bbf04997e48abfca','tx_themecamino_list_item',27,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',14,'',0,0,2147483647,0,0,''),
('906fbb042bcbe28fc887dd9185304bb1','tx_themecamino_list_item',27,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',18,'',0,0,2147483647,0,0,''),
('924b61fe4a4d0fd7961bab073f311363','tt_content',12,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',2,0,'tx_themecamino_list_item',22,'',0,0,2147483647,0,0,''),
('92535c0a700f4e67aafefdf7e0fee153','tx_themecamino_list_item',23,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',12,'',0,0,2147483647,0,0,''),
('92cadd14c472c4bb7e7cb8eb35d468b6','tx_themecamino_list_item',3,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',4,'',0,0,2147483647,0,0,''),
('953556e7bc639bfdd74d25ff389911b1','tt_content',5,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',5,'',0,0,2147483647,0,0,''),
('9623baa766db7f3edb61b54f05d23e27','sys_file_reference',5,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('97905997f3ee88e3b0849c31d058ae25','tt_content',12,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',21,'',0,0,2147483647,0,0,''),
('9fcf222f07f184bfefb9ba2946018eb2','tt_content',13,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',25,'',0,0,2147483647,0,0,''),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b0933f546e43cdad405bd96e7efc74e9','tx_themecamino_list_item',4,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',4,'',0,0,2147483647,0,0,''),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b54cc0640c341db723cae8172ba718d9','tt_content',8,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',17,'',0,0,2147483647,0,0,''),
('b930f9bd3488c5e7af3d40e0b84fd0fe','tx_themecamino_list_item',17,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',8,'',0,0,2147483647,0,0,''),
('b973768d91a8c0e27ff105992df25a88','tx_themecamino_list_item',2,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',4,'',0,0,2147483647,0,0,''),
('b9fecd7babb9fb62db3622801ea567bb','tx_themecamino_list_item',32,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',16,'',0,0,2147483647,0,0,''),
('ba9ea6aa389e167a3f181b15416f225b','tt_content',5,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',2,0,'tx_themecamino_list_item',19,'',0,0,2147483647,0,0,''),
('bb07476d9b0172491715d5ea40709c28','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('bbbd68f02ebee584eaecb580ac1c2470','tx_themecamino_list_item',32,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',17,'',0,0,2147483647,0,0,''),
('be14f798546d3b92f7ef1e0aea6502b8','tt_content',20,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',18,'',0,0,2147483647,0,0,''),
('bfc6b03aba76464d2bb557e46f5257d7','tx_themecamino_list_item',15,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',8,'',0,0,2147483647,0,0,''),
('c84e59a5b28aa5f51370b5e21bfbe54b','sys_file_reference',5,'l10n_parent',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('c85ba41fd4c5d3b71defde9442917ff6','tx_themecamino_list_item',13,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('c90b7fe112c5bbe1e19992296f936eb3','tt_content',4,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',2,'',0,0,2147483647,0,0,''),
('c9cf5608e06761feeb7d685c3703ea1e','tt_content',13,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',24,'',0,0,2147483647,0,0,''),
('cc1f6d226407c30cb30283989e14ee39','tx_themecamino_list_item',5,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',5,'',0,0,2147483647,0,0,''),
('ccec6cca4b8e1b4fd3b32319943d7722','tt_content',10,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('d0f1acbd8e8e6a7f12507e2a26f5aa50','tt_content',7,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',14,'',0,0,2147483647,0,0,''),
('d2eb96365ba02e864bf4baf0f4e3a509','tt_content',4,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',3,0,'tx_themecamino_list_item',4,'',0,0,2147483647,0,0,''),
('d337dd2ab67dae739fcba5a6510553a2','tt_content',9,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',2,'',0,0,2147483647,0,0,''),
('d4a7c25efac166ae44353db499dae749','pages',2,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('d4c59ad17cf6b38b44350eb56a21a520','tx_themecamino_list_item',26,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',19,'',0,0,2147483647,0,0,''),
('d4e07111257b740746665f4476ad996f','tx_themecamino_list_item',35,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',22,'',0,0,2147483647,0,0,''),
('d7024e0f51606af203f0acc8f49452f1','tt_content',12,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',3,0,'tx_themecamino_list_item',23,'',0,0,2147483647,0,0,''),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('d9609dae5e61eac40b6d5497e340b8ab','tx_themecamino_list_item',24,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',5,'',0,0,2147483647,0,0,''),
('db526678f32b1df1823ca585f2acc3dc','tx_themecamino_list_item',28,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',8,'',0,0,2147483647,0,0,''),
('e979f5172b9aa804c27b98c901dc724c','sys_file_reference',2,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('eda804720165e965b3f41d9774812ec9','tt_content',7,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',13,'',0,0,2147483647,0,0,''),
('f00773d80be9502ea88ccc6f035d9ab2','tt_content',21,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',19,'',0,0,2147483647,0,0,''),
('f08dc42a4689b59f54680214eec7834a','tt_content',16,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',32,'',0,0,2147483647,0,0,''),
('f0ab18b6e67b5e3726d1b49c3dc22786','tt_content',22,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',17,'',0,0,2147483647,0,0,''),
('f1060057d3831662f7c80aa11f7b6b9b','tt_content',16,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',31,'',0,0,2147483647,0,0,''),
('f520acdb6fc94cdeef803ad88c25b8bb','tt_content',17,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',33,'',0,0,2147483647,0,0,''),
('f66be31ed8272c2a63bb23a4db5ea6a7','tt_content',2,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('f9042899478d22a5c4b43cee8c04f4bb','tx_themecamino_list_item',1,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',4,'',0,0,2147483647,0,0,''),
('fa2c30b709798fc0d57b79a3e62fc2d3','tt_content',5,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',7,'',0,0,2147483647,0,0,''),
('fb8f1882ff4981a1dbe053161b24e7ef','tt_content',18,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('ff5a9695bab693075908812f34511f4b','tx_themecamino_list_item',28,'uid_foreign',0,0,2147483647,0,'','','',0,0,'tt_content',14,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Setup\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(9,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(11,'core','formProtectionSessionToken:3','s:64:\"84862c1c9923fdfc07faa4f22b8645559126e58d36abaf42d2a7b33b233b480f\";'),
(12,'core','formProtectionSessionToken:1','s:64:\"8cab8cc2da8182381726984e6e0133f6d2a3459ff371278025110923be72cbe2\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_themecamino_list_elements` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_themecamino_link` text NOT NULL DEFAULT '',
  `tx_themecamino_link_label` text NOT NULL DEFAULT '',
  `tx_themecamino_link_config` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_link_icon` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_header_style` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1771588552,1771582455,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"bodytext\":\"\",\"header\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Benefits',0,'','','','<h2>🚀 Publish faster</h2>\r\n<p>Small changes (headlines, teasers, CTA copy) take seconds instead of minutes.</p>\r\n<h2>🎯 Fewer errors, less back-and-forth</h2>\r\n<p>Edits happen in layout context — fewer “Oops, wrong content block” moments.</p>\r\n<h2>🧠 Less training required</h2>\r\n<p>Editors get it instantly: click = edit.</p>\r\n<h2>🧩 Built for TYPO3</h2>\r\n<p>No foreign layer, no “second CMS”. Cleanly integrated into the TYPO3 ecosystem.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','','',0),
(2,1,1771588536,1771588457,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"hidden\":\"\",\"image\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',2,NULL,0,'camino_hero_small',0,0,'','',0,'New Look, New Feel',0,'','','A fresh foundation for every project',NULL,1,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'https://github.com/andersundsehr/visual_editor','Read more','0','',0),
(3,1,1771589179,1771588619,0,0,0,0,'',128,NULL,0,0,0,0,NULL,'{\"header\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Visual Editing for TYPO3',0,'','','Because it is just natural that way.','<p>Edit content directly where it\'s created: on the page. No more form streaks or tab hopping — just click, tap, and you\'re done. <strong>What you see is what you ship:</strong> <a href=\"t3://page?uid=15\">headlines</a>, teasers, and CTAs update in context, so teams move faster, make fewer mistakes, and need less back-and-forth.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(4,1,1771588651,1771588651,0,0,0,0,'',64,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',11,NULL,0,'camino_sociallinks',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,4,'','','','',0),
(5,1,1771588977,1771588687,0,0,0,0,'',32,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',12,NULL,0,'camino_linklist',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,3,'','','','',0),
(6,1,1771588965,1771588702,0,0,0,0,'',16,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',13,NULL,0,'camino_linklist',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,2,'','','','',0),
(7,1,1771589006,1771588749,0,0,0,0,'',8,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',14,NULL,0,'camino_linklist',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,2,'','','','',0),
(8,1,1771588821,1771588772,0,0,0,0,'',4,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',10,NULL,0,'camino_linklist',0,0,'','',0,'Footer',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,2,'','','','',0),
(9,1,1771589169,1771589092,0,0,0,0,'',384,NULL,0,1,2,2,NULL,'{\"CType\":\"camino_hero_small\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"2\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"New Look, New Feel\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"1\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"A fresh foundation for every project\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"https:\\/\\/github.com\\/andersundsehr\\/visual_editor\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"Read more\",\"tx_themecamino_list_elements\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',2,NULL,0,'camino_hero_small',0,0,'','',0,'New Look, New Feel',0,'','','Eine neue Basis für jedes Projekt',NULL,1,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,'https://github.com/andersundsehr/visual_editor','Mehr lesen','0','',0),
(10,1,1771589265,1771589092,0,0,0,0,'',192,NULL,0,1,3,3,NULL,'{\"CType\":\"text\",\"assets\":\"0\",\"bodytext\":\"<p>Edit content directly where it\'s created: on the page. No more form streaks or tab hopping \\u2014 just click, tap, and you\'re done. <strong>What you see is what you ship:<\\/strong> <a href=\\\"t3:\\/\\/page?uid=15\\\">headlines<\\/a>, teasers, and CTAs update in context, so teams move faster, make fewer mistakes, and need less back-and-forth.<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Visual Editing f\\u00fcr TYPO3\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"Because it is just natural that way.\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Visual Editing für TYPO3',0,'','','Weil es einfach so natürlich ist.','<p>Bearbeiten Sie Inhalte direkt dort, wo sie erstellt werden: auf der Seite.&nbsp;<br />Keine Formularfelder oder Tab-Wechsel mehr – einfach klicken, tippen und fertig.&nbsp;<br /><strong>Was Sie sehen, ist es, was Sie veröffentlichen:</strong> Überschriften, Teaser und <a href=\"t3://page?uid=1\">CTAs </a>werden im Kontext aktualisiert, sodass Teams schneller arbeiten, weniger Fehler machen und weniger Hin und Her benötigen.</p>',0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,'','','0','',0),
(11,1,1771589302,1771589092,0,0,0,0,'',224,NULL,0,1,1,1,NULL,'{\"CType\":\"text\",\"assets\":\"0\",\"bodytext\":\"<h2>\\ud83d\\ude80 Publish faster<\\/h2>\\r\\n<p>Small changes (headlines, teasers, CTA copy) take seconds instead of minutes.<\\/p>\\r\\n<h2>\\ud83c\\udfaf Fewer errors, less back-and-forth<\\/h2>\\r\\n<p>Edits happen in layout context \\u2014 fewer \\u201cOops, wrong content block\\u201d moments.<\\/p>\\r\\n<h2>\\ud83e\\udde0 Less training required<\\/h2>\\r\\n<p>Editors get it instantly: click = edit.<\\/p>\\r\\n<h2>\\ud83e\\udde9 Built for TYPO3<\\/h2>\\r\\n<p>No foreign layer, no \\u201csecond CMS\\u201d. Cleanly integrated into the TYPO3 ecosystem.<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Benefits\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Vorteile',0,'','','','<h2>🚀 Schneller veröffentlichen</h2>\r\n<p>Kleine Änderungen (Überschriften, Teaser, CTA-Texte) dauern nur Sekunden statt Minuten.</p>\r\n<h2>🎯 Weniger Fehler, weniger Hin und Her</h2>\r\n<p>Bearbeitungen erfolgen im Layout-Kontext – weniger „Hoppla, falscher Inhaltsblock“-Momente.</p>\r\n<h2>🧠 Weniger Schulungsaufwand</h2>\r\n<p>Redakteure verstehen es sofort: Klicken = bearbeiten.</p>\r\n<h2>🧩 Entwickelt für TYPO3</h2>\r\n<p>Keine fremde Ebene, kein „zweites CMS“. Sauber in das TYPO3-Ökosystem integriert.</p>',0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,'','','','',0),
(12,1,1771589101,1771589092,0,0,0,0,'',96,NULL,0,1,4,4,NULL,'{\"CType\":\"camino_sociallinks\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"11\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"4\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',11,NULL,0,'camino_sociallinks',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,4,'','','','',0),
(13,1,1771589101,1771589092,0,0,0,0,'',48,NULL,0,1,5,5,NULL,'{\"CType\":\"camino_linklist\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"12\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"3\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',12,NULL,0,'camino_linklist',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,3,'','','','',0),
(14,1,1771589100,1771589092,0,0,0,0,'',24,NULL,0,1,6,6,NULL,'{\"CType\":\"camino_linklist\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"13\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"2\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',13,NULL,0,'camino_linklist',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,2,'','','','',0),
(15,1,1771589099,1771589092,0,0,0,0,'',12,NULL,0,1,7,7,NULL,'{\"CType\":\"camino_linklist\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"14\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"2\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',14,NULL,0,'camino_linklist',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,2,'','','','',0),
(16,1,1771589103,1771589092,0,0,0,0,'',6,NULL,0,1,8,8,NULL,'{\"CType\":\"camino_linklist\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"10\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Footer\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"2\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',10,NULL,0,'camino_linklist',0,0,'','',0,'Footer',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,2,'','','','',0),
(17,3,1771589455,1771589455,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"hidden\":\"\",\"image\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',1,NULL,0,'camino_author',0,0,'','',0,'Matthias Vogel',0,'','','Technical Leader','Maintainer of:\r\n- EXT:visual_editor\r\n- EXT:storybook\r\n- webdevops/php',1,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,2,'','','','',0),
(18,3,1771590217,1771589511,0,0,0,0,'',128,NULL,0,0,0,0,NULL,'{\"header\":\"\"}',0,0,0,0,'default',2,NULL,0,'camino_hero_small',0,0,'','',0,'Effortless Digital.',0,'','','We build experiences that feel simple for users and stay solid behind the scenes.',NULL,1,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(19,3,1771589845,1771589750,0,0,0,0,'',64,NULL,0,0,0,0,NULL,'{\"bodytext\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'',0,'','','','<p>We are <strong>anders und sehr</strong>, an award-winning 360 degree digital agency based in Stuttgart. We bring <strong>creation</strong>, <strong>marketing</strong>, and <strong>digital platforms</strong> together in one team, so strategy, design, and technology work as a coherent whole from day one.</p>\r\n<p>As <strong>digital architects</strong>, we believe great digital work needs more than a beautiful facade. It needs a foundation that lasts. That is why we start with concept and planning, challenge assumptions early, and then craft the finished solution with the same love for detail. We build everything, but no castles in the air.</p>\r\n<p>What makes us different is <strong>ideas</strong>. Even the smallest idea can create real impact when it is unique and speaks directly to the people you want to reach. We see ourselves as explorers and pioneers, opening new horizons and turning vision into reality.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(20,3,1771590311,1771589810,0,0,0,0,'',192,NULL,0,1,18,18,NULL,'{\"CType\":\"camino_hero_small\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"2\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Effortless Digital.\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"1\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"We build experiences that feel simple for users and stay solid behind the scenes.\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',2,NULL,0,'camino_hero_small',0,0,'','',0,'Digitale Leichtigkeit.',0,'','','Wir schaffen einfache Nutzererlebnisse, die im Hintergrund reibungslos laufen.',NULL,1,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,'','','0','',0),
(21,3,1771589885,1771589810,0,0,0,0,'',96,NULL,0,1,19,19,NULL,'{\"CType\":\"text\",\"assets\":\"0\",\"bodytext\":\"<p>We are <strong>anders und sehr<\\/strong>, an award-winning 360 degree digital agency based in Stuttgart. We bring <strong>creation<\\/strong>, <strong>marketing<\\/strong>, and <strong>digital platforms<\\/strong> together in one team, so strategy, design, and technology work as a coherent whole from day one.<\\/p>\\r\\n<p>As <strong>digital architects<\\/strong>, we believe great digital work needs more than a beautiful facade. It needs a foundation that lasts. That is why we start with concept and planning, challenge assumptions early, and then craft the finished solution with the same love for detail. We build everything, but no castles in the air.<\\/p>\\r\\n<p>What makes us different is <strong>ideas<\\/strong>. Even the smallest idea can create real impact when it is unique and speaks directly to the people you want to reach. We see ourselves as explorers and pioneers, opening new horizons and turning vision into reality.<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'',0,'','','','<p>Wir sind <strong>anders und sehr</strong>, eine preisgekrönte 360-Grad-Digitalagentur mit Sitz in Stuttgart. Wir vereinen <strong>Kreation</strong>, <strong>Marketing </strong>und <strong>digitale Plattformen </strong>in einem Team, sodass Strategie, Design und Technologie vom ersten Tag an als stimmiges Ganzes funktionieren.</p>\r\n<p>Als <strong>digitale Architekten </strong>glauben wir, dass großartige digitale Arbeit mehr als nur eine schöne Fassade braucht. Sie braucht ein Fundament, das Bestand hat. Deshalb beginnen wir mit Konzept und Planung, hinterfragen frühzeitig Annahmen und entwickeln dann mit der gleichen Liebe zum Detail die fertige Lösung. Wir bauen alles, aber keine Luftschlösser.</p>\r\n<p>Was uns auszeichnet, sind <strong>Ideen</strong>. Selbst die kleinste Idee kann eine echte Wirkung erzielen, wenn sie einzigartig ist und die Menschen, die Sie erreichen wollen, direkt anspricht. Wir verstehen uns als Entdecker und Pioniere, die neue Horizonte eröffnen und Visionen Wirklichkeit werden lassen.</p>',0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,'','','0','',0),
(22,3,1771589834,1771589810,0,0,0,0,'',512,NULL,0,1,17,17,NULL,'{\"CType\":\"camino_author\",\"assets\":\"0\",\"bodytext\":\"Maintainer of:\\r\\n- EXT:visual_editor\\r\\n- EXT:storybook\\r\\n- webdevops\\/php\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"1\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Matthias Vogel\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"1\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"Technical Leader\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"tx_themecamino_header_style\":\"0\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_list_elements\":\"2\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',1,NULL,0,'camino_author',0,0,'','',0,'Matthias Vogel',0,'','','Technical Leader','Maintainer von:\n- EXT:visual_editor\n- EXT:storybook\n- webdevops/php',1,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,2,'','','','',0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_themecamino_list_item`
--

DROP TABLE IF EXISTS `tx_themecamino_list_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_themecamino_list_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` longtext DEFAULT NULL,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `fieldname` varchar(255) NOT NULL DEFAULT '',
  `category` varchar(50) NOT NULL DEFAULT '',
  `date` bigint(20) DEFAULT NULL,
  `header` text NOT NULL DEFAULT '',
  `images` int(10) unsigned NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `link_config` varchar(255) NOT NULL DEFAULT '',
  `link_icon` varchar(255) NOT NULL DEFAULT '',
  `link_label` text NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_themecamino_list_item`
--

LOCK TABLES `tx_themecamino_list_item` WRITE;
/*!40000 ALTER TABLE `tx_themecamino_list_item` DISABLE KEYS */;
INSERT INTO `tx_themecamino_list_item` VALUES
(1,1,1771588651,1771588651,0,0,1,0,0,0,NULL,'',0,0,0,0,'4','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.instagram.com/anders.und.sehr/','','','',NULL),
(2,1,1771588651,1771588651,0,0,3586,0,0,0,NULL,'',0,0,0,0,'4','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.facebook.com/andersundsehr','','','',NULL),
(3,1,1771588651,1771588651,0,0,4611,0,0,0,NULL,'',0,0,0,0,'4','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://de.linkedin.com/company/anders-und-sehr','','','',NULL),
(4,1,1771588651,1771588651,0,0,5636,0,0,0,NULL,'',0,0,0,0,'4','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.xing.com/pages/andersundsehrgmbh','','','',NULL),
(5,1,1771589045,1771588687,0,0,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'5','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr/aus_driver_amazon_s3','','','ET:aus_driver_amazon_s3',NULL),
(6,1,1771588906,1771588687,1,0,3,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'5','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/webdevops/Dockerfile','','','webdevops/php',NULL),
(7,1,1771589045,1771588687,0,0,3586,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'5','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr/storybook','','','EXT:storybook',NULL),
(8,1,1771589034,1771588702,0,0,3586,0,0,0,NULL,'{\"hidden\":\"\",\"link\":\"\",\"link_label\":\"\"}',0,0,0,0,'6','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr','','','github.com/andersundsehr',NULL),
(9,1,1771588965,1771588715,1,0,2,0,0,0,NULL,'{\"hidden\":\"\",\"link\":\"\",\"link_label\":\"\"}',0,0,0,0,'6','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr/storybook','','','EXT:storybook',NULL),
(10,1,1771588965,1771588715,1,0,3,0,0,0,NULL,'{\"hidden\":\"\",\"link\":\"\",\"link_label\":\"\"}',0,0,0,0,'6','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr/aus_driver_amazon_s3','','','ET:aus_driver_amazon_s3',NULL),
(11,1,1771589006,1771588749,1,0,1,0,0,0,NULL,'{\"hidden\":\"\",\"link\":\"\",\"link_label\":\"\"}',0,0,0,0,'7','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.andersundsehr.com/landing-pages/KI-Chatbot','','','Bumblebee - der KI-Chatbot',NULL),
(12,1,1771588892,1771588749,1,0,2,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'7','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr/aus_driver_amazon_s3','','','ET:aus_driver_amazon_s3',NULL),
(13,1,1771589055,1771588749,0,0,3586,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'7','tt_content','tx_themecamino_list_elements','',NULL,'',0,'http://github.com/pluswerk/php-dev','','','php-dev',NULL),
(14,1,1771589055,1771588749,0,0,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'7','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/webdevops/Dockerfile','','','webdevops/php',NULL),
(15,1,1771588821,1771588772,0,0,1,0,0,0,NULL,'{\"hidden\":\"\",\"link\":\"\",\"link_label\":\"\"}',0,0,0,0,'8','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.andersundsehr.com/impressum','','','Impressum',NULL),
(16,1,1771588821,1771588790,1,0,2,0,0,0,NULL,'',0,0,0,0,'8','tt_content','tx_themecamino_list_elements','',NULL,'',0,'t3://page?uid=1','','','Legal',NULL),
(17,1,1771588821,1771588790,0,0,3586,0,0,0,NULL,'{\"hidden\":\"\",\"link\":\"\",\"link_label\":\"\"}',0,0,0,0,'8','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.andersundsehr.com/datenschutzhinweis','','','Datenschutzhinweiß',NULL),
(18,1,1771589034,1771588965,0,0,1,0,0,0,NULL,'{\"hidden\":\"\",\"link\":\"\",\"link_label\":\"\"}',0,0,0,0,'6','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.andersundsehr.com/landing-pages/KI-Chatbot','','','Bumblebee - der KI-Chatbot',NULL),
(19,1,1771589045,1771588977,0,0,4611,0,0,0,NULL,'{\"hidden\":\"\",\"link\":\"\",\"link_label\":\"\"}',0,0,0,0,'5','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr/grumphp-config','','','pkg:grumphp-config',NULL),
(20,1,1771589092,1771589092,0,0,1,1,1,1,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/www.instagram.com\\/anders.und.sehr\\/\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"sorting_foreign\":\"1\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"4\"}',0,0,0,0,'12','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.instagram.com/anders.und.sehr/','','','',NULL),
(21,1,1771589092,1771589092,0,0,3074,1,2,2,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/www.facebook.com\\/andersundsehr\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"sorting_foreign\":\"514\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"4\"}',0,0,0,0,'12','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.facebook.com/andersundsehr','','','',NULL),
(22,1,1771589092,1771589092,0,0,3075,1,3,3,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/de.linkedin.com\\/company\\/anders-und-sehr\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"sorting_foreign\":\"1027\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"4\"}',0,0,0,0,'12','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://de.linkedin.com/company/anders-und-sehr','','','',NULL),
(23,1,1771589092,1771589092,0,0,3076,1,4,4,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/www.xing.com\\/pages\\/andersundsehrgmbh\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"sorting_foreign\":\"1540\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"4\"}',0,0,0,0,'12','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.xing.com/pages/andersundsehrgmbh','','','',NULL),
(24,1,1771589092,1771589092,0,0,1,1,5,5,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/aus_driver_amazon_s3\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"ET:aus_driver_amazon_s3\",\"sorting_foreign\":\"1\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"5\"}',0,0,0,0,'13','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr/aus_driver_amazon_s3','','','ET:aus_driver_amazon_s3',NULL),
(25,1,1771589092,1771589092,0,0,2562,1,7,7,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/storybook\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"EXT:storybook\",\"sorting_foreign\":\"1026\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"5\"}',0,0,0,0,'13','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr/storybook','','','EXT:storybook',NULL),
(26,1,1771589092,1771589092,0,0,2563,1,19,19,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/github.com\\/andersundsehr\\/grumphp-config\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"pkg:grumphp-config\",\"sorting_foreign\":\"2051\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"5\"}',0,0,0,0,'13','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr/grumphp-config','','','pkg:grumphp-config',NULL),
(27,1,1771589092,1771589092,0,0,1,1,18,18,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/www.andersundsehr.com\\/landing-pages\\/KI-Chatbot\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Bumblebee - der KI-Chatbot\",\"sorting_foreign\":\"1\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"6\"}',0,0,0,0,'14','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.andersundsehr.com/landing-pages/KI-Chatbot','','','Bumblebee - der KI-Chatbot',NULL),
(28,1,1771589092,1771589092,0,0,2050,1,8,8,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/github.com\\/andersundsehr\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"github.com\\/andersundsehr\",\"sorting_foreign\":\"1538\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"6\"}',0,0,0,0,'14','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/andersundsehr','','','github.com/andersundsehr',NULL),
(29,1,1771589092,1771589092,0,0,1,1,14,14,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/github.com\\/webdevops\\/Dockerfile\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"webdevops\\/php\",\"sorting_foreign\":\"1\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"7\"}',0,0,0,0,'15','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://github.com/webdevops/Dockerfile','','','webdevops/php',NULL),
(30,1,1771589092,1771589092,0,0,1026,1,13,13,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"http:\\/\\/github.com\\/pluswerk\\/php-dev\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"php-dev\",\"sorting_foreign\":\"2562\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"7\"}',0,0,0,0,'15','tt_content','tx_themecamino_list_elements','',NULL,'',0,'http://github.com/pluswerk/php-dev','','','php-dev',NULL),
(31,1,1771589092,1771589092,0,0,1,1,15,15,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/www.andersundsehr.com\\/impressum\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Impressum\",\"sorting_foreign\":\"1\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"8\"}',0,0,0,0,'16','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.andersundsehr.com/impressum','','','Impressum',NULL),
(32,1,1771589092,1771589092,0,0,2,1,17,17,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/www.andersundsehr.com\\/datenschutzhinweis\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Datenschutzhinwei\\u00df\",\"sorting_foreign\":\"3586\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"8\"}',0,0,0,0,'16','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.andersundsehr.com/datenschutzhinweis','','','Datenschutzhinweiß',NULL),
(33,3,1771589455,1771589455,0,0,1,0,0,0,NULL,'',0,0,0,0,'17','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://mastodontech.de/@kanti','','','Mastodon',NULL),
(34,3,1771589455,1771589455,0,0,514,0,0,0,NULL,'',0,0,0,0,'17','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://typo3.slack.com/team/U046M1E1J','','','TYPO3 Slack',NULL),
(35,3,1771589810,1771589810,0,0,1,1,33,33,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/mastodontech.de\\/@kanti\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Mastodon\",\"sorting_foreign\":\"1\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"17\"}',0,0,0,0,'22','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://mastodontech.de/@kanti','','','Mastodon',NULL),
(36,3,1771589810,1771589810,0,0,2,1,34,34,NULL,'{\"category\":\"\",\"date\":\"\",\"fieldname\":\"tx_themecamino_list_elements\",\"header\":\"\",\"hidden\":\"0\",\"images\":\"0\",\"l10n_source\":\"0\",\"link\":\"https:\\/\\/typo3.slack.com\\/team\\/U046M1E1J\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"TYPO3 Slack\",\"sorting_foreign\":\"514\",\"tablename\":\"tt_content\",\"text\":\"\",\"uid_foreign\":\"17\"}',0,0,0,0,'22','tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://typo3.slack.com/team/U046M1E1J','','','TYPO3 Slack',NULL);
/*!40000 ALTER TABLE `tx_themecamino_list_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-20 13:41:27
